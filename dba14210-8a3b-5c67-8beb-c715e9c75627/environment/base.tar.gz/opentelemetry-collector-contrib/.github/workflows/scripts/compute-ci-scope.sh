#!/usr/bin/env bash
# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

set -euo pipefail

# ======================================================================================
# Optimizes CI by calculating the minimum set of modules that need testing based
# on the files changed in a Pull Request. It outputs two JSON matrices for
# GitHub Actions:
#   - matrix:        modules + transitive dependents (build/test/checks).
#   - direct_matrix: modules whose files actually changed (lint-only -- a
#                    downstream module's lint result doesn't depend on whether
#                    an upstream module's source changed).
# The logic goes like this:
# 1. If 'ci:full' label is present OR event is not a PR -> Full Matrix (both).
# 2. If core build files (Makefile, workflows) changed -> Full Matrix (both).
# 3. Identifies Go modules directly modified by the git diff (direct_matrix).
# 4. Recursively finds modules that depend on the modified modules
#    (e.g., if 'pkg/ottl' changes, we must test 'processor/filterprocessor').
# 5. Groups each resulting set of modules into a fixed number of "buckets"
#    (TARGET_CONCURRENCY) to prevent spawning hundreds of concurrent CI jobs.
#
#
# Environment variables:
#   ALL_TEST_GROUPS (Required in CI): JSON array of the fallback/full group list.
#   PR_HEAD     (Optional): SHA of the PR tip. Defaults to 'HEAD' locally.
#   BASE_REF    (Optional): Branch target. Defaults to 'main' locally.
#   TARGET_CONCURRENCY    (Optional): Max concurrent buckets. Defaults to 10.
#   FORCE_ALL  (Optional): Set to "true" to force full matrix output.
# ======================================================================================

# Ensure we are in the repo root
repo_root="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [[ -z "${repo_root}" ]]; then
  echo "error: must be run inside a git repo" >&2
  exit 2
fi
cd "${repo_root}"

# -----------------------------------------------------------------------------
# Define local variables
# -----------------------------------------------------------------------------
if [[ -z "${GITHUB_ACTIONS:-}" ]]; then
  # If not running in GitHub Actions, set defaults for local testing.
  echo "Running in local mode." >&2
  export EVENT_NAME="pull_request"
  export BASE_REF="${BASE_REF:-main}" # Default to comparing against main
  export PR_HEAD="${PR_HEAD:-HEAD}"
  export GITHUB_OUTPUT="/dev/stdout" # Print results to console

  # Mock ALL_TEST_GROUPS if not provided locally
  if [[ -z "${ALL_TEST_GROUPS:-}" ]]; then
    ALL_TEST_GROUPS='["receiver-0","receiver-1","receiver-2","receiver-3","processor-0","processor-1","exporter-0","exporter-1","exporter-2","exporter-3","extension","connector","internal","pkg","cmd-0","other"]'
  fi
  # Mock CRITICAL_FILES if not provided locally
  if [[ -z "${CRITICAL_FILES:-}" ]]; then
    CRITICAL_FILES='["Makefile", "Makefile.Common", ".golangci.yml", ".github/workflows/", "internal/tools/", "versions.yaml"]'
  fi
else
  # In CI, these are mandatory.
  : "${ALL_TEST_GROUPS:?The ALL_TEST_GROUPS environment variable is required}"
  : "${CRITICAL_FILES:?The CRITICAL_FILES environment variable is required}"
fi

# Sanitize inputs
ALL_TEST_GROUPS="$(echo "${ALL_TEST_GROUPS}" | tr -d '\n' | tr -s ' ')"
TARGET_CONCURRENCY=${TARGET_CONCURRENCY:-10}
GITHUB_OUTPUT="${GITHUB_OUTPUT:-/dev/stdout}"

# -----------------------------------------------------------------------------
# Helper functions
# -----------------------------------------------------------------------------
exit_full_mode() {
  echo "Reason: $1" >&2
  echo "Selecting FULL Matrix." >&2
  echo "matrix=${ALL_TEST_GROUPS}" >> "$GITHUB_OUTPUT"
  echo "direct_matrix=${ALL_TEST_GROUPS}" >> "$GITHUB_OUTPUT"
  exit 0
}

exit_scoped_mode() {
  local matrix_json="$1"
  local count="$2"
  local direct_matrix_json="${3:-$matrix_json}"
  local direct_count="${4:-$count}"
  echo "Reason: Scoped changes detected ($count modules affected, $direct_count direct)." >&2
  echo "Computed Matrix:        ${matrix_json}" >&2
  echo "Computed Direct Matrix: ${direct_matrix_json}" >&2
  echo "matrix=${matrix_json}" >> "$GITHUB_OUTPUT"
  echo "direct_matrix=${direct_matrix_json}" >> "$GITHUB_OUTPUT"
  exit 0
}

# -----------------------------------------------------------------------------
# Check if script should keep running
# -----------------------------------------------------------------------------

# Manual label override
if [[ "${FORCE_ALL:-}" == "true" ]]; then
  exit_full_mode "Manual override detected (Label: 'ci:full')."
fi

# Non-PR Events (Push, Schedule, Merge Group)
# Note: In local mode, we forced this to 'pull_request' above so this passes.
if [[ "${EVENT_NAME:-}" != "pull_request" ]]; then
  exit_full_mode "Non-PR event (${EVENT_NAME:-unknown})."
fi

# -----------------------------------------------------------------------------
# Check what changed
# -----------------------------------------------------------------------------
echo "Calculating git diff against origin/${BASE_REF}..." >&2

# Fetch origin/main locally if needed to ensure comparison works
if [[ -z "${GITHUB_ACTIONS:-}" ]]; then
  git fetch origin "${BASE_REF}" >/dev/null 2>&1 || true
fi

# Calculate the merge base
base_sha="$(git merge-base "origin/${BASE_REF}" "${PR_HEAD}")"
changed_files="$(git diff --name-only --diff-filter=ACMRTUXB "${base_sha}" "${PR_HEAD}")"

if [[ -z "${changed_files}" ]]; then
  echo "No changed files detected." >&2
  exit_scoped_mode "[]" 0
fi

# -----------------------------------------------------------------------------
# Check if there are changes to infrastructure files
# -----------------------------------------------------------------------------

while IFS= read -r pattern; do
  if echo "${changed_files}" | grep -q "$pattern"; then
    exit_full_mode "At least one critical file changed: $pattern."
  fi
done < <(echo "$CRITICAL_FILES" | jq -r '.[]')

# -----------------------------------------------------------------------------
# Get dependencies of the modules changed
# -----------------------------------------------------------------------------
find_module_dir_for_file() {
  local d
  d="$(dirname "$1")"
  [[ "$d" == "." ]] && d=""
  while [[ "$d" != "." && "$d" != "/" ]]; do
    if [[ -f "${d}/go.mod" ]]; then
      echo "${d}" | sed 's|^\./||'; return 0
    fi
    d="$(dirname "${d}")"
  done
  if [[ -f "go.mod" ]]; then echo "."; fi
}

read_module_name() {
  local mod_file="$1/go.mod"
  [[ "$1" == "." ]] && mod_file="go.mod"
  if [[ -f "$mod_file" ]]; then
    awk '$1=="module"{print $2; exit}' "$mod_file"
  fi
}

declare -A affected_dirs

# Map files to modules
while IFS= read -r f; do
  [[ -z "${f}" ]] && continue
  f="${f#./}"
  mod_dir="$(find_module_dir_for_file "${f}")"
  [[ -n "${mod_dir}" ]] && affected_dirs["${mod_dir}"]=1
done <<< "${changed_files}"

if [[ ${#affected_dirs[@]} -eq 0 ]]; then
  exit_scoped_mode "[]" 0
fi

# Snapshot directly-changed modules before transitive expansion. Lint runs
# against this set only -- a downstream module's lint result doesn't depend
# on whether an upstream module's source changed, so dragging transitive
# dependents into the lint matrix wastes time.
declare -A direct_dirs
for dir in "${!affected_dirs[@]}"; do
  direct_dirs["${dir}"]=1
done

# Resolve Transitive Dependencies
all_go_mods="$(find . -type f -name "go.mod" -not -path "*/.git/*" -not -path "*/vendor/*")"

while true; do
  found_new=false
  grep_patterns="$(mktemp)"

  for dir in "${!affected_dirs[@]}"; do
    mod_name="$(read_module_name "${dir}")"
    if [[ -n "${mod_name}" ]]; then
      mod_name_escaped="${mod_name//./\\.}"
      echo "${mod_name_escaped}[[:space:]]" >> "$grep_patterns"
    fi
  done

  if [[ -s "$grep_patterns" ]]; then
    dependents=$(echo "$all_go_mods" | xargs grep -l -f "$grep_patterns" || true)
    if [[ -n "${dependents}" ]]; then
       while IFS= read -r dependent_mod_file; do
        dep_dir="$(dirname "${dependent_mod_file}")"
        dep_dir="${dep_dir#./}"
        [[ "${dep_dir}" == "." ]] && dep_dir="."
        if [[ -z "${affected_dirs[${dep_dir}]+x}" ]]; then
          affected_dirs["${dep_dir}"]=1
          found_new=true
        fi
      done <<< "${dependents}"
    fi
  fi
  rm -f "$grep_patterns"
  [[ "${found_new}" == "false" ]] && break
done

# -----------------------------------------------------------------------------
# Bucket results so we can launch multiple workers on CI
# -----------------------------------------------------------------------------
bucket_dirs_to_json() {
  local -n _dirs=$1
  local -a _buckets
  for ((i=0; i<TARGET_CONCURRENCY; i++)); do _buckets[$i]=""; done

  local idx=0 bucket_id
  for dir in "${!_dirs[@]}"; do
    bucket_id=$((idx % TARGET_CONCURRENCY))
    # The Makefile uses "/" in GROUP to tell module paths from named
    # groups; single-segment paths (e.g. "testbed") need a "/" or they
    # route to a nonexistent `for-<name>-target`.
    if [[ "${dir}" != "." && "${dir}" != */* ]]; then
      dir="./${dir}"
    fi
    if [[ -z "${_buckets[$bucket_id]}" ]]; then
      _buckets[$bucket_id]="${dir}"
    else
      _buckets[$bucket_id]="${_buckets[$bucket_id]} ${dir}"
    fi
    idx=$((idx + 1))
  done

  local out="[" first=true
  for bucket in "${_buckets[@]}"; do
    if [[ -n "${bucket}" ]]; then
      [[ "$first" == "true" ]] && first=false || out+=","
      out+="\"${bucket}\""
    fi
  done
  out+="]"
  echo "${out}"
}

json_array="$(bucket_dirs_to_json affected_dirs)"
direct_json_array="$(bucket_dirs_to_json direct_dirs)"

exit_scoped_mode "${json_array}" "${#affected_dirs[@]}" "${direct_json_array}" "${#direct_dirs[@]}"