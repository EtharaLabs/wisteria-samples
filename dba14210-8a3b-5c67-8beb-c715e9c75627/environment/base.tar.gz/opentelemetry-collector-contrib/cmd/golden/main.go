// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package main // import "github.com/open-telemetry/opentelemetry-collector-contrib/cmd/golden"

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/config/configoptional"
	"go.opentelemetry.io/collector/confmap"
	"go.opentelemetry.io/collector/receiver"
	"go.opentelemetry.io/collector/receiver/otlpreceiver"
	noopmetric "go.opentelemetry.io/otel/metric/noop"
	nooptrace "go.opentelemetry.io/otel/trace/noop"
	"go.uber.org/zap"

	"github.com/open-telemetry/opentelemetry-collector-contrib/cmd/golden/internal"
)

// insertDefault is a helper function to insert a default value for a configoptional.Optional type.
func insertDefault[T any](opt *configoptional.Optional[T]) error {
	if opt.HasValue() {
		return nil
	}

	empty := confmap.NewFromStringMap(map[string]any{})
	return empty.Unmarshal(opt)
}

func main() {
	if err := run(os.Args); err != nil {
		log.Fatal(err)
	}
}

func run(args []string) error {
	cfg, err := internal.ReadConfig(args)
	if err != nil {
		return err
	}

	sink, err := internal.NewConsumer(cfg)
	if err != nil {
		return err
	}

	factory := otlpreceiver.NewFactory()
	receiverConfig := factory.CreateDefaultConfig().(*otlpreceiver.Config)
	if cfg.OTLPHTTPEndoint != "" {
		if insertErr := insertDefault(&receiverConfig.Protocols.HTTP); insertErr != nil {
			return insertErr
		}
		receiverConfig.Protocols.HTTP.Get().ServerConfig.NetAddr.Endpoint = cfg.OTLPHTTPEndoint
	}

	if cfg.OTLPEndpoint != "" {
		if insertErr := insertDefault(&receiverConfig.Protocols.GRPC); insertErr != nil {
			return insertErr
		}
		receiverConfig.Protocols.GRPC.Get().NetAddr.Endpoint = cfg.OTLPEndpoint
	}

	logger, err := zap.NewDevelopment()
	if err != nil {
		return err
	}

	set := receiver.Settings{
		ID: component.MustNewID(factory.Type().String()),
		TelemetrySettings: component.TelemetrySettings{
			Logger:         logger,
			MeterProvider:  noopmetric.NewMeterProvider(),
			TracerProvider: nooptrace.NewTracerProvider(),
		},
		BuildInfo: component.BuildInfo{},
	}

	otlpReceiver, err := factory.CreateMetrics(context.Background(), set, receiverConfig, sink)
	if err != nil {
		return err
	}

	err = otlpReceiver.Start(context.Background(), componenttest.NewNopHost())
	if err != nil {
		return err
	}
	defer func() {
		_ = otlpReceiver.Shutdown(context.Background())
	}()

	ticker := time.NewTicker(cfg.Timeout)
	timeout := false
	select {
	case <-ticker.C:
		logger.Error("Timeout waiting for data")
		timeout = true
	case <-sink.DoneChan:
	}

	if len(sink.Errors) > 0 {
		var errMsg strings.Builder
		fmt.Fprintf(&errMsg, "comparison failed with %d error(s):\n", len(sink.Errors))
		for _, attemptErr := range sink.Errors {
			fmt.Fprintf(&errMsg, "  Attempt %d: %v\n", attemptErr.AttemptNumber, attemptErr.Error)
		}
		return errors.New(errMsg.String())
	}
	if timeout {
		return errors.New("timeout waiting for data")
	}

	return nil
}
