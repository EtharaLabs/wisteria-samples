// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

//go:generate make mdatagen

package main // import "github.com/open-telemetry/opentelemetry-collector-contrib/cmd/opampsupervisor"
