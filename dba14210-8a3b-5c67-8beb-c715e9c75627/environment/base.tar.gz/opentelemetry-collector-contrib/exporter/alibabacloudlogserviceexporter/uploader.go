// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package alibabacloudlogserviceexporter // import "github.com/open-telemetry/opentelemetry-collector-contrib/exporter/alibabacloudlogserviceexporter"

import (
	"errors"
	"fmt"
	"net"
	"os"

	sls "github.com/aliyun/aliyun-log-go-sdk"
	"github.com/aliyun/aliyun-log-go-sdk/producer"
	slsutil "github.com/aliyun/aliyun-log-go-sdk/util"
	"go.uber.org/zap"
)

// logServiceClient log Service's client wrapper
type logServiceClient interface {
	// sendLogs send message to LogService
	sendLogs(logs []*sls.Log) error
}

type logServiceClientImpl struct {
	clientInstance *producer.Producer
	project        string
	logstore       string
	topic          string
	source         string
	logger         *zap.Logger
}

func getIPAddress() (ipAddress string, err error) {
	as, err := net.InterfaceAddrs()
	for _, a := range as {
		if in, ok := a.(*net.IPNet); ok && !in.IP.IsLoopback() {
			if in.IP.To4() != nil {
				ipAddress = in.IP.String()
			}
		}
	}
	return ipAddress, err
}

// newLogServiceClient Create Log Service client
func newLogServiceClient(config *Config, logger *zap.Logger) (logServiceClient, error) {
	if config == nil || config.Endpoint == "" || config.Project == "" || config.Logstore == "" {
		return nil, errors.New("missing logservice params: Endpoint, Project, Logstore")
	}

	producerConfig := newProducerConfig(config)

	producer, err := producer.NewProducer(producerConfig)
	if err != nil {
		return nil, fmt.Errorf("failed to create Log Service producer: %w", err)
	}

	c := &logServiceClientImpl{
		project:        config.Project,
		logstore:       config.Logstore,
		clientInstance: producer,
		logger:         logger,
	}
	c.clientInstance.Start()
	// do not return error if get hostname or ip address fail
	c.topic, _ = os.Hostname()
	c.source, _ = getIPAddress()
	logger.Info("Create LogService client success", zap.String("project", config.Project), zap.String("logstore", config.Logstore))
	return c, nil
}

func newProducerConfig(config *Config) *producer.ProducerConfig {
	producerConfig := producer.GetDefaultProducerConfig()
	producerConfig.Endpoint = config.Endpoint
	producerConfig.AccessKeyID = config.AccessKeyID
	producerConfig.AccessKeySecret = string(config.AccessKeySecret)
	if config.ECSRamRole != "" || config.TokenFilePath != "" {
		tokenUpdateFunc, _ := slsutil.NewTokenUpdateFunc(config.ECSRamRole, config.TokenFilePath)
		provider := sls.NewUpdateFuncProviderAdapter(tokenUpdateFunc)
		producerConfig.CredentialsProvider = provider

		producerConfig.StsTokenShutDown = make(chan struct{})
	} else if config.SecurityToken != "" {
		producerConfig.CredentialsProvider = sls.NewStaticCredentialsProvider(
			config.AccessKeyID,
			string(config.AccessKeySecret),
			string(config.SecurityToken),
		)
	}

	return producerConfig
}

// sendLogs send message to LogService
func (c *logServiceClientImpl) sendLogs(logs []*sls.Log) error {
	return c.clientInstance.SendLogListWithCallBack(c.project, c.logstore, c.topic, c.source, logs, c)
}

// Success is impl of producer.CallBack
func (*logServiceClientImpl) Success(*producer.Result) {}

// Fail is impl of producer.CallBack
func (c *logServiceClientImpl) Fail(result *producer.Result) {
	c.logger.Warn("Send to LogService failed",
		zap.String("project", c.project),
		zap.String("store", c.logstore),
		zap.String("code", result.GetErrorCode()),
		zap.String("error_message", result.GetErrorMessage()),
		zap.String("request_id", result.GetRequestId()))
}
