// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package alertmanagerexporter // import "github.com/open-telemetry/opentelemetry-collector-contrib/exporter/alertmanagerexporter"

import (
	"context"
	"errors"
	"time"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/config/confighttp"
	"go.opentelemetry.io/collector/config/configoptional"
	"go.opentelemetry.io/collector/config/configretry"
	"go.opentelemetry.io/collector/exporter"
	"go.opentelemetry.io/collector/exporter/exporterhelper"

	"github.com/open-telemetry/opentelemetry-collector-contrib/exporter/alertmanagerexporter/internal/metadata"
)

// NewFactory creates a factory for Alertmanager exporter
func NewFactory() exporter.Factory {
	return exporter.NewFactory(
		metadata.Type,
		createDefaultConfig,
		exporter.WithLogs(createLogsExporter, metadata.LogsStability),
		exporter.WithTraces(createTracesExporter, metadata.TracesStability),
	)
}

func createDefaultConfig() component.Config {
	clientConfig := confighttp.NewDefaultClientConfig()
	clientConfig.Endpoint = "http://localhost:9093"
	clientConfig.Timeout = 30 * time.Second
	clientConfig.WriteBufferSize = 512 * 1024

	return &Config{
		GeneratorURL:    "opentelemetry-collector",
		DefaultSeverity: "info",
		APIVersion:      "v2",
		EventLabels:     []string{"attr1", "attr2"},
		TimeoutSettings: exporterhelper.NewDefaultTimeoutConfig(),
		BackoffConfig:   configretry.NewDefaultBackOffConfig(),
		QueueSettings:   configoptional.Some(exporterhelper.NewDefaultQueueConfig()),
		ClientConfig:    clientConfig,
	}
}

func createTracesExporter(ctx context.Context, set exporter.Settings, config component.Config) (exporter.Traces, error) {
	cfg := config.(*Config)

	if cfg.ClientConfig.Endpoint == "" {
		return nil, errors.New(
			"exporter config requires a non-empty \"endpoint\"",
		)
	}
	return newTracesExporter(ctx, cfg, set)
}

func createLogsExporter(ctx context.Context, set exporter.Settings, config component.Config) (exporter.Logs, error) {
	cfg := config.(*Config)

	if cfg.ClientConfig.Endpoint == "" {
		return nil, errors.New(
			"exporter config requires a non-empty \"endpoint\"",
		)
	}
	return newLogsExporter(ctx, cfg, set)
}
