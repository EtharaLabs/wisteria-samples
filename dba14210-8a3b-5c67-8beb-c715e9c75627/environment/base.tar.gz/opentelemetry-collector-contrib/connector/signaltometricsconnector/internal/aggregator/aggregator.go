// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package aggregator // import "github.com/open-telemetry/opentelemetry-collector-contrib/connector/signaltometricsconnector/internal/aggregator"

import (
	"context"
	"fmt"
	"strings"
	"time"

	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.uber.org/zap"

	"github.com/open-telemetry/opentelemetry-collector-contrib/connector/signaltometricsconnector/internal/metadata"
	"github.com/open-telemetry/opentelemetry-collector-contrib/connector/signaltometricsconnector/internal/model"
	"github.com/open-telemetry/opentelemetry-collector-contrib/pkg/ottl"
	"github.com/open-telemetry/opentelemetry-collector-contrib/pkg/pdatautil"
)

// FilterAttrsFunc is a lazy function that produces a filtered attribute map.
// It is only called when the aggregator encounters a new unique attribute
// set and needs to create a datapoint. This avoids allocating a pcommon.Map
// for every signal item.
type FilterAttrsFunc func() (pcommon.Map, error)

// Aggregator provides a single interface to update all metrics
// datastructures. The required datastructure is selected using
// the metric definition.
type Aggregator[K any] struct {
	result pmetric.Metrics
	// smLookup maps resourceID against scope metrics since the aggregator
	// always produces a single scope.
	smLookup    map[[16]byte]pmetric.ScopeMetrics
	valueCounts map[model.MetricKey]map[[16]byte]map[[16]byte]*valueCountDP
	sums        map[model.MetricKey]map[[16]byte]map[[16]byte]*sumDP
	gauges      map[model.MetricKey]map[[16]byte]map[[16]byte]*gaugeDP
	timestamp   time.Time
	errorMode   ottl.ErrorMode
	logger      *zap.Logger
}

// NewAggregator creates a new instance of aggregator.
func NewAggregator[K any](metrics pmetric.Metrics, errorMode ottl.ErrorMode, logger *zap.Logger) *Aggregator[K] {
	return &Aggregator[K]{
		result:      metrics,
		smLookup:    make(map[[16]byte]pmetric.ScopeMetrics),
		valueCounts: make(map[model.MetricKey]map[[16]byte]map[[16]byte]*valueCountDP),
		sums:        make(map[model.MetricKey]map[[16]byte]map[[16]byte]*sumDP),
		gauges:      make(map[model.MetricKey]map[[16]byte]map[[16]byte]*gaugeDP),
		timestamp:   time.Now(),
		errorMode:   errorMode,
		logger:      logger,
	}
}

func (a *Aggregator[K]) Aggregate(
	ctx context.Context,
	tCtx K,
	md model.MetricDef[K],
	resAttrs pcommon.Map,
	attrID [16]byte,
	filterAttrs FilterAttrsFunc,
	defaultCount int64,
) error {
	switch md.Key.Type {
	case pmetric.MetricTypeExponentialHistogram:
		val, count, err := getValueCount(
			ctx, tCtx,
			md.ExponentialHistogram.Value,
			md.ExponentialHistogram.Count,
			defaultCount,
		)
		if err != nil {
			return a.handleError(err)
		}
		if err := a.aggregateValueCount(md, resAttrs, attrID, filterAttrs, val, count); err != nil {
			return a.handleError(err)
		}
	case pmetric.MetricTypeHistogram:
		val, count, err := getValueCount(
			ctx, tCtx,
			md.ExplicitHistogram.Value,
			md.ExplicitHistogram.Count,
			defaultCount,
		)
		if err != nil {
			return a.handleError(err)
		}
		if err := a.aggregateValueCount(md, resAttrs, attrID, filterAttrs, val, count); err != nil {
			return a.handleError(err)
		}
	case pmetric.MetricTypeSum:
		raw, err := md.Sum.Value.Eval(ctx, tCtx)
		if err != nil {
			return a.handleError(fmt.Errorf("failed to execute OTTL value for sum: %w", err))
		}
		switch v := raw.(type) {
		case int64:
			if err := a.aggregateInt(md, resAttrs, attrID, filterAttrs, v); err != nil {
				return a.handleError(err)
			}
		case float64:
			if err := a.aggregateDouble(md, resAttrs, attrID, filterAttrs, v); err != nil {
				return a.handleError(err)
			}
		default:
			return a.handleError(fmt.Errorf(
				"failed to parse sum OTTL value of type %T into int64 or float64: %v",
				v, v,
			))
		}
	case pmetric.MetricTypeGauge:
		raw, err := md.Gauge.Value.Eval(ctx, tCtx)
		if err != nil {
			if strings.Contains(err.Error(), "key not found in map") {
				// Gracefully skip missing keys in ExtractGrokPatterns
				return nil
			}
			return a.handleError(fmt.Errorf("failed to execute OTTL value for gauge: %w", err))
		}
		if raw == nil {
			return nil
		}
		switch v := raw.(type) {
		case int64, float64:
			if err := a.aggregateGauge(md, resAttrs, attrID, filterAttrs, v); err != nil {
				return a.handleError(err)
			}
		default:
			return a.handleError(fmt.Errorf(
				"failed to parse gauge OTTL value of type %T into int64 or float64: %v",
				v, v,
			))
		}
	}
	return nil
}

// handleError handles errors based on the configured ErrorMode.
// It returns nil for ignore/silent modes and returns the error for propagate mode.
func (a *Aggregator[K]) handleError(err error) error {
	switch a.errorMode {
	case ottl.PropagateError:
		return err
	case ottl.IgnoreError:
		a.logger.Error("Error processing data", zap.Error(err))
		return nil
	case ottl.SilentError:
		return nil
	default:
		return err
	}
}

// Finalize finalizes the aggregations performed by the aggregator so far into
// the pmetric.Metrics used to create this instance of the aggregator. Finalize
// should be called once per aggregator instance and the aggregator instance
// should not be used after Finalize is called.
func (a *Aggregator[K]) Finalize(mds []model.MetricDef[K]) {
	for _, md := range mds {
		for resID, dpMap := range a.valueCounts[md.Key] {
			metrics := a.smLookup[resID].Metrics()
			var (
				destExpHist      pmetric.ExponentialHistogram
				destExplicitHist pmetric.Histogram
			)
			switch md.Key.Type {
			case pmetric.MetricTypeExponentialHistogram:
				destMetric := metrics.AppendEmpty()
				destMetric.SetName(md.Key.Name)
				destMetric.SetUnit(md.Key.Unit)
				destMetric.SetDescription(md.Key.Description)
				destExpHist = destMetric.SetEmptyExponentialHistogram()
				destExpHist.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)
				destExpHist.DataPoints().EnsureCapacity(len(dpMap))
			case pmetric.MetricTypeHistogram:
				destMetric := metrics.AppendEmpty()
				destMetric.SetName(md.Key.Name)
				destMetric.SetUnit(md.Key.Unit)
				destMetric.SetDescription(md.Key.Description)
				destExplicitHist = destMetric.SetEmptyHistogram()
				destExplicitHist.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)
				destExplicitHist.DataPoints().EnsureCapacity(len(dpMap))
			}
			for _, dp := range dpMap {
				dp.Copy(
					a.timestamp,
					destExpHist,
					destExplicitHist,
				)
			}
		}
		for resID, dpMap := range a.sums[md.Key] {
			if md.Sum == nil {
				continue
			}
			metrics := a.smLookup[resID].Metrics()
			destMetric := metrics.AppendEmpty()
			destMetric.SetName(md.Key.Name)
			destMetric.SetUnit(md.Key.Unit)
			destMetric.SetDescription(md.Key.Description)
			destCounter := destMetric.SetEmptySum()
			destCounter.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)
			destCounter.SetIsMonotonic(md.Sum.IsMonotonic)
			destCounter.DataPoints().EnsureCapacity(len(dpMap))
			for _, dp := range dpMap {
				dp.Copy(a.timestamp, destCounter.DataPoints().AppendEmpty())
			}
		}
		for resID, dpMap := range a.gauges[md.Key] {
			if md.Gauge == nil {
				continue
			}
			metrics := a.smLookup[resID].Metrics()
			destMetric := metrics.AppendEmpty()
			destMetric.SetName(md.Key.Name)
			destMetric.SetUnit(md.Key.Unit)
			destMetric.SetDescription(md.Key.Description)
			destGauge := destMetric.SetEmptyGauge()
			destGauge.DataPoints().EnsureCapacity(len(dpMap))
			for _, dp := range dpMap {
				dp.Copy(a.timestamp, destGauge.DataPoints().AppendEmpty())
			}
		}
		// If there are two metric defined with the same key required by metricKey
		// then they will be aggregated within the same metric and produced
		// together. Deleting the key ensures this while preventing duplicates.
		delete(a.valueCounts, md.Key)
		delete(a.sums, md.Key)
		delete(a.gauges, md.Key)
	}
}

func (a *Aggregator[K]) aggregateInt(
	md model.MetricDef[K],
	resAttrs pcommon.Map,
	attrID [16]byte,
	filterAttrs FilterAttrsFunc,
	v int64,
) error {
	resID := a.getResourceID(resAttrs)
	if _, ok := a.sums[md.Key]; !ok {
		a.sums[md.Key] = make(map[[16]byte]map[[16]byte]*sumDP)
	}
	if _, ok := a.sums[md.Key][resID]; !ok {
		a.sums[md.Key][resID] = make(map[[16]byte]*sumDP)
	}
	if _, ok := a.sums[md.Key][resID][attrID]; !ok {
		filtered, err := filterAttrs()
		if err != nil {
			return err
		}
		a.sums[md.Key][resID][attrID] = newSumDP(filtered, false)
	}
	a.sums[md.Key][resID][attrID].AggregateInt(v)
	return nil
}

func (a *Aggregator[K]) aggregateDouble(
	md model.MetricDef[K],
	resAttrs pcommon.Map,
	attrID [16]byte,
	filterAttrs FilterAttrsFunc,
	v float64,
) error {
	resID := a.getResourceID(resAttrs)
	if _, ok := a.sums[md.Key]; !ok {
		a.sums[md.Key] = make(map[[16]byte]map[[16]byte]*sumDP)
	}
	if _, ok := a.sums[md.Key][resID]; !ok {
		a.sums[md.Key][resID] = make(map[[16]byte]*sumDP)
	}
	if _, ok := a.sums[md.Key][resID][attrID]; !ok {
		filtered, err := filterAttrs()
		if err != nil {
			return err
		}
		a.sums[md.Key][resID][attrID] = newSumDP(filtered, true)
	}
	a.sums[md.Key][resID][attrID].AggregateDouble(v)
	return nil
}

func (a *Aggregator[K]) aggregateGauge(
	md model.MetricDef[K],
	resAttrs pcommon.Map,
	attrID [16]byte,
	filterAttrs FilterAttrsFunc,
	v any,
) error {
	resID := a.getResourceID(resAttrs)
	if _, ok := a.gauges[md.Key]; !ok {
		a.gauges[md.Key] = make(map[[16]byte]map[[16]byte]*gaugeDP)
	}
	if _, ok := a.gauges[md.Key][resID]; !ok {
		a.gauges[md.Key][resID] = make(map[[16]byte]*gaugeDP)
	}
	if _, ok := a.gauges[md.Key][resID][attrID]; !ok {
		filtered, err := filterAttrs()
		if err != nil {
			return err
		}
		a.gauges[md.Key][resID][attrID] = newGaugeDP(filtered)
	}
	a.gauges[md.Key][resID][attrID].Aggregate(v)
	return nil
}

func (a *Aggregator[K]) aggregateValueCount(
	md model.MetricDef[K],
	resAttrs pcommon.Map,
	attrID [16]byte,
	filterAttrs FilterAttrsFunc,
	value float64, count int64,
) error {
	if count == 0 {
		// Nothing to record as count is zero
		return nil
	}
	resID := a.getResourceID(resAttrs)
	if _, ok := a.valueCounts[md.Key]; !ok {
		a.valueCounts[md.Key] = make(map[[16]byte]map[[16]byte]*valueCountDP)
	}
	if _, ok := a.valueCounts[md.Key][resID]; !ok {
		a.valueCounts[md.Key][resID] = make(map[[16]byte]*valueCountDP)
	}
	if _, ok := a.valueCounts[md.Key][resID][attrID]; !ok {
		filtered, err := filterAttrs()
		if err != nil {
			return err
		}
		a.valueCounts[md.Key][resID][attrID] = newValueCountDP(md, filtered)
	}
	a.valueCounts[md.Key][resID][attrID].Aggregate(value, count)
	return nil
}

func (a *Aggregator[K]) getResourceID(resourceAttrs pcommon.Map) [16]byte {
	resID := pdatautil.MapHash(resourceAttrs)
	if _, ok := a.smLookup[resID]; !ok {
		destResourceMetric := a.result.ResourceMetrics().AppendEmpty()
		destResAttrs := destResourceMetric.Resource().Attributes()
		destResAttrs.EnsureCapacity(resourceAttrs.Len() + 1)
		resourceAttrs.CopyTo(destResAttrs)
		destScopeMetric := destResourceMetric.ScopeMetrics().AppendEmpty()
		destScopeMetric.Scope().SetName(metadata.ScopeName)
		a.smLookup[resID] = destScopeMetric
	}
	return resID
}

// getValueCount evaluates OTTL to get count and value respectively. Count is
// optional and defaults to the default count if the OTTL statement for count
// is missing. Value is required and returns an error if OTTL statement for
// value is missing.
func getValueCount[K any](
	ctx context.Context, tCtx K,
	valueExpr, countExpr *ottl.ValueExpression[K],
	defaultCount int64,
) (float64, int64, error) {
	val, err := getDoubleFromOTTL(ctx, tCtx, valueExpr)
	if err != nil {
		return 0, 0, fmt.Errorf("failed to get value from OTTL: %w", err)
	}
	count := defaultCount
	if countExpr != nil {
		count, err = getIntFromOTTL(ctx, tCtx, countExpr)
		if err != nil {
			return 0, 0, fmt.Errorf("failed to get count from OTTL: %w", err)
		}
	}
	return val, count, nil
}

func getIntFromOTTL[K any](
	ctx context.Context,
	tCtx K,
	s *ottl.ValueExpression[K],
) (int64, error) {
	if s == nil {
		return 0, nil
	}
	raw, err := s.Eval(ctx, tCtx)
	if err != nil {
		return 0, err
	}
	switch v := raw.(type) {
	case int64:
		return v, nil
	case float64:
		return int64(v), nil
	default:
		return 0, fmt.Errorf(
			"failed to parse int OTTL value, expression returned value of type %T: %v",
			v, v,
		)
	}
}

func getDoubleFromOTTL[K any](
	ctx context.Context,
	tCtx K,
	s *ottl.ValueExpression[K],
) (float64, error) {
	if s == nil {
		return 0, nil
	}
	raw, err := s.Eval(ctx, tCtx)
	if err != nil {
		return 0, err
	}
	switch v := raw.(type) {
	case float64:
		return v, nil
	case int64:
		return float64(v), nil
	default:
		return 0, fmt.Errorf(
			"failed to parse double OTTL value, expression returned value of type %T: %v",
			v, v,
		)
	}
}
