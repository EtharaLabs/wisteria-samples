// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package spanmetricsconnector

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/gobwas/glob"
	"github.com/jonboulle/clockwork"
	"github.com/lightstep/go-expohisto/structure"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/config/configoptional"
	"go.opentelemetry.io/collector/connector/connectortest"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/consumer/consumertest"
	"go.opentelemetry.io/collector/featuregate"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"go.uber.org/zap/zaptest"
	"go.uber.org/zap/zaptest/observer"
	"google.golang.org/grpc/metadata"

	spanmetricsmetadata "github.com/open-telemetry/opentelemetry-collector-contrib/connector/spanmetricsconnector/internal/metadata"
	"github.com/open-telemetry/opentelemetry-collector-contrib/connector/spanmetricsconnector/internal/metrics"
	"github.com/open-telemetry/opentelemetry-collector-contrib/internal/pdatautil"
)

const (
	stringAttrName           = "stringAttrName"
	intAttrName              = "intAttrName"
	doubleAttrName           = "doubleAttrName"
	boolAttrName             = "boolAttrName"
	nullAttrName             = "nullAttrName"
	mapAttrName              = "mapAttrName"
	arrayAttrName            = "arrayAttrName"
	notInSpanAttrName0       = "shouldBeInMetric"
	notInSpanAttrName1       = "shouldNotBeInMetric"
	regionResourceAttrName   = "region"
	exceptionTypeAttrName    = "exception.type"
	resourceMetricsCacheSize = 5

	sampleRegion   = "us-east-1"
	sampleDuration = 11 * time.Millisecond

	instanceID = "0044953a-2946-449f-a5c8-2971f2a63928"
)

// metricID represents the minimum attributes that uniquely identifies a metric in our tests.
type metricID struct {
	service             string
	name                string
	kind                string
	statusCode          string
	collectorInstanceID string
	otelStatusCode      string
}

type metricDataPoint interface {
	Attributes() pcommon.Map
}

type serviceSpans struct {
	serviceName string
	spans       []span
}

type span struct {
	name       string
	kind       ptrace.SpanKind
	statusCode ptrace.StatusCode
	traceID    [16]byte
	spanID     [8]byte
	tracestate string
}

// verifyDisabledHistogram expects that histograms are disabled.
func verifyDisabledHistogram(tb testing.TB, input pmetric.Metrics) bool {
	for i := 0; i < input.ResourceMetrics().Len(); i++ {
		rm := input.ResourceMetrics().At(i)
		ism := rm.ScopeMetrics()
		// Checking all metrics, naming notice: ismC/mC - C here is for Counter.
		for ismC := 0; ismC < ism.Len(); ismC++ {
			m := ism.At(ismC).Metrics()
			for mC := 0; mC < m.Len(); mC++ {
				metric := m.At(mC)
				assert.NotEqual(tb, pmetric.MetricTypeExponentialHistogram, metric.Type())
				assert.NotEqual(tb, pmetric.MetricTypeHistogram, metric.Type())
			}
		}
	}
	return true
}

func verifyExemplarsExist(tb testing.TB, input pmetric.Metrics) bool {
	for i := 0; i < input.ResourceMetrics().Len(); i++ {
		rm := input.ResourceMetrics().At(i)
		ism := rm.ScopeMetrics()

		// Checking all metrics, naming notice: ismC/mC - C here is for Counter.
		for ismC := 0; ismC < ism.Len(); ismC++ {
			m := ism.At(ismC).Metrics()

			for mC := 0; mC < m.Len(); mC++ {
				metric := m.At(mC)

				if metric.Type() != pmetric.MetricTypeHistogram {
					continue
				}
				dps := metric.Histogram().DataPoints()
				for dp := 0; dp < dps.Len(); dp++ {
					d := dps.At(dp)
					assert.Positive(tb, d.Exemplars().Len())
				}
			}
		}
	}
	return true
}

// verifyConsumeMetricsInputCumulative expects one accumulation of metrics, and marked as cumulative
func verifyConsumeMetricsInputCumulative(tb testing.TB, input pmetric.Metrics) bool {
	return verifyConsumeMetricsInput(tb, input, pmetric.AggregationTemporalityCumulative, 1)
}

func verifyBadMetricsOkay(testing.TB, pmetric.Metrics) bool {
	return true // Validating no exception
}

func verifyOtelStatusCode(tb testing.TB, input pmetric.Metrics) bool {
	require.Equal(tb, 8, input.DataPointCount(),
		"Should be 4 for each of call count and latency split into three resource scopes defined by: "+
			"service-a: service-a (server kind) -> service-a (client kind), "+
			"service-b: service-b (server kind), and"+
			"service-c: service-c (server kind)",
	)

	require.Equal(tb, 3, input.ResourceMetrics().Len())

	for i := 0; i < input.ResourceMetrics().Len(); i++ {
		rm := input.ResourceMetrics().At(i)

		ilm := rm.ScopeMetrics()
		require.Equal(tb, 1, ilm.Len())
		assert.Equal(tb, "spanmetricsconnector", ilm.At(0).Scope().Name())

		m := ilm.At(0).Metrics()
		require.Equal(tb, 2, m.Len(), "only sum and histogram metric types generated")

		metric := m.At(0)
		// validate the sum metrics for simplicity
		assert.Equal(tb, pmetric.MetricTypeSum, metric.Type())
		seenMetricIDs := make(map[metricID]bool)

		dataPoints := metric.Sum().DataPoints()
		var expectedStatusCode string
		var serviceName string

		for dpi := 0; dpi < dataPoints.Len(); dpi++ {
			dp := dataPoints.At(dpi)

			val, ok := dp.Attributes().Get(serviceNameKey)
			require.True(tb, ok)
			if serviceName == "" {
				serviceName = val.AsString()
				switch serviceName {
				case "service-a":
					expectedStatusCode = "OK"
				case "service-b":
					expectedStatusCode = "ERROR"
				case "service-c":
					expectedStatusCode = ""
				default:
					require.Fail(tb, fmt.Sprintf("Unexpected service name: %s", serviceName))
				}
			}
			require.Equal(tb, serviceName, val.AsString())

			statusCode, ok := dp.Attributes().Get(otelStatusCodeKey)
			if expectedStatusCode == "" {
				require.False(tb, ok)
			} else {
				require.True(tb, ok)
				assert.Equal(tb, expectedStatusCode, statusCode.AsString())
			}
			verifyMetricLabels(tb, dp, seenMetricIDs)
		}
		for id := range seenMetricIDs {
			assert.Equal(tb, expectedStatusCode, id.otelStatusCode)
			assert.Empty(tb, id.statusCode)
		}
	}
	return true
}

// verifyConsumeMetricsInputDelta expects one accumulation of metrics, and marked as delta
func verifyConsumeMetricsInputDelta(tb testing.TB, input pmetric.Metrics) bool {
	return verifyConsumeMetricsInput(tb, input, pmetric.AggregationTemporalityDelta, 1)
}

// verifyMultipleCumulativeConsumptions expects the amount of accumulations as kept track of by numCumulativeConsumptions.
// numCumulativeConsumptions acts as a multiplier for the values, since the cumulative metrics are additive.
func verifyMultipleCumulativeConsumptions() func(tb testing.TB, input pmetric.Metrics) bool {
	numCumulativeConsumptions := 0
	return func(tb testing.TB, input pmetric.Metrics) bool {
		numCumulativeConsumptions++
		return verifyConsumeMetricsInput(tb, input, pmetric.AggregationTemporalityCumulative, numCumulativeConsumptions)
	}
}

// verifyConsumeMetricsInput verifies the input of the ConsumeMetrics call from this connector.
// This is the best point to verify the computed metrics from spans are as expected.
func verifyConsumeMetricsInput(tb testing.TB, input pmetric.Metrics, expectedTemporality pmetric.AggregationTemporality, numCumulativeConsumptions int) bool {
	require.Equal(tb, 6, input.DataPointCount(),
		"Should be 3 for each of call count and latency split into two resource scopes defined by: "+
			"service-a: service-a (server kind) -> service-a (client kind) and "+
			"service-b: service-b (service kind)",
	)

	require.Equal(tb, 2, input.ResourceMetrics().Len())

	for i := 0; i < input.ResourceMetrics().Len(); i++ {
		rm := input.ResourceMetrics().At(i)

		// validate no Resource
		assert.Empty(tb, rm.Resource().Attributes().Len())

		ilm := rm.ScopeMetrics()
		require.Equal(tb, 1, ilm.Len())
		assert.Equal(tb, "spanmetricsconnector", ilm.At(0).Scope().Name())

		m := ilm.At(0).Metrics()
		require.Equal(tb, 2, m.Len(), "only sum and histogram metric types generated")

		// validate calls - sum metrics
		metric := m.At(0)
		assert.Equal(tb, metricNameCalls, metric.Name())
		assert.Equal(tb, expectedTemporality, metric.Sum().AggregationTemporality())
		assert.True(tb, metric.Sum().IsMonotonic())

		seenMetricIDs := make(map[metricID]bool)
		callsDps := metric.Sum().DataPoints()
		var numDataPoints int
		val, _ := callsDps.At(0).Attributes().Get(serviceNameKey)
		serviceName := val.AsString()
		switch serviceName {
		case "service-a":
			numDataPoints = 2
		case "service-b":
			numDataPoints = 1
		}

		require.Equal(tb, numDataPoints, callsDps.Len())
		for dpi := 0; dpi < numDataPoints; dpi++ {
			dp := callsDps.At(dpi)
			expectIntValue := numCumulativeConsumptions
			// this calls init value is 0 for the first Consumption.
			if expectedTemporality == pmetric.AggregationTemporalityCumulative && numCumulativeConsumptions == 1 {
				expectIntValue = 0
			}
			assert.Equal(tb,
				int64(expectIntValue),
				dp.IntValue(),
				"There should only be one metric per Service/name/kind combination",
			)
			assert.NotZero(tb, dp.StartTimestamp(), "StartTimestamp should be set")
			assert.NotZero(tb, dp.Timestamp(), "Timestamp should be set")
			verifyMetricLabels(tb, dp, seenMetricIDs)
		}

		// validate latency - histogram metrics
		metric = m.At(1)
		assert.Equal(tb, metricNameDuration, metric.Name())
		assert.Equal(tb, defaultUnit.String(), metric.Unit())

		if metric.Type() == pmetric.MetricTypeExponentialHistogram {
			hist := metric.ExponentialHistogram()
			assert.Equal(tb, expectedTemporality, hist.AggregationTemporality())
			verifyExponentialHistogramDataPoints(tb, hist.DataPoints(), numDataPoints, numCumulativeConsumptions)
		} else {
			hist := metric.Histogram()
			assert.Equal(tb, expectedTemporality, hist.AggregationTemporality())
			verifyExplicitHistogramDataPoints(tb, hist.DataPoints(), numDataPoints, numCumulativeConsumptions)
		}
	}
	return true
}

func verifyExplicitHistogramDataPoints(tb testing.TB, dps pmetric.HistogramDataPointSlice, numDataPoints, numCumulativeConsumptions int) {
	seenMetricIDs := make(map[metricID]bool)
	require.Equal(tb, numDataPoints, dps.Len())
	for dpi := range numDataPoints {
		dp := dps.At(dpi)
		assert.Equal(
			tb,
			sampleDuration.Seconds()*float64(numCumulativeConsumptions),
			dp.Sum(),
			"Should be a 11ms duration measurement, multiplied by the number of stateful accumulations.",
		)
		assert.NotZero(tb, dp.Timestamp(), "Timestamp should be set")

		// Verify bucket counts.

		// The bucket counts should be 1 greater than the explicit bounds as documented in:
		// https://github.com/open-telemetry/opentelemetry-proto/blob/main/opentelemetry/proto/metrics/v1/metrics.proto.
		assert.Equal(tb, dp.ExplicitBounds().Len()+1, dp.BucketCounts().Len())

		// Find the bucket index where the 11ms duration should belong in.
		var foundDurationIndex int
		for foundDurationIndex = 0; foundDurationIndex < dp.ExplicitBounds().Len(); foundDurationIndex++ {
			if dp.ExplicitBounds().At(foundDurationIndex) > sampleDuration.Seconds() {
				break
			}
		}

		// Then verify that all histogram buckets are empty except for the bucket with the 11ms duration.
		var wantBucketCount uint64
		for bi := 0; bi < dp.BucketCounts().Len(); bi++ {
			wantBucketCount = 0
			if bi == foundDurationIndex {
				wantBucketCount = uint64(numCumulativeConsumptions)
			}
			assert.Equal(tb, wantBucketCount, dp.BucketCounts().At(bi))
		}
		verifyMetricLabels(tb, dp, seenMetricIDs)
	}
}

func verifyExponentialHistogramDataPoints(tb testing.TB, dps pmetric.ExponentialHistogramDataPointSlice, numDataPoints, numCumulativeConsumptions int) {
	seenMetricIDs := make(map[metricID]bool)
	require.Equal(tb, numDataPoints, dps.Len())
	for dpi := range numDataPoints {
		dp := dps.At(dpi)
		assert.Equal(
			tb,
			sampleDuration.Seconds()*float64(numCumulativeConsumptions),
			dp.Sum(),
			"Should be a 11ms duration measurement, multiplied by the number of stateful accumulations.",
		)
		assert.Equal(tb, uint64(numCumulativeConsumptions), dp.Count())
		assert.Equal(tb, []uint64{uint64(numCumulativeConsumptions)}, dp.Positive().BucketCounts().AsRaw())
		assert.NotZero(tb, dp.Timestamp(), "Timestamp should be set")

		verifyMetricLabels(tb, dp, seenMetricIDs)
	}
}

func verifyMetricLabels(tb testing.TB, dp metricDataPoint, seenMetricIDs map[metricID]bool) {
	mID := metricID{}
	wantDimensions := map[string]pcommon.Value{
		stringAttrName:         pcommon.NewValueStr("stringAttrValue"),
		intAttrName:            pcommon.NewValueInt(99),
		doubleAttrName:         pcommon.NewValueDouble(99.99),
		boolAttrName:           pcommon.NewValueBool(true),
		nullAttrName:           pcommon.NewValueEmpty(),
		arrayAttrName:          pcommon.NewValueSlice(),
		mapAttrName:            pcommon.NewValueMap(),
		notInSpanAttrName0:     pcommon.NewValueStr("defaultNotInSpanAttrVal"),
		regionResourceAttrName: pcommon.NewValueStr(sampleRegion),
	}
	for k, v := range dp.Attributes().All() {
		switch k {
		case serviceNameKey:
			mID.service = v.Str()
		case spanNameKey:
			mID.name = v.Str()
		case spanKindKey:
			mID.kind = v.Str()
		case statusCodeKey:
			mID.statusCode = v.Str()
		case collectorInstanceKey:
			mID.collectorInstanceID = v.Str()
		case otelStatusCodeKey:
			mID.otelStatusCode = v.Str()
		case metricAttrSamplingMethod:
			// sampling.method attribute is always present, verify it's either "counted" or "extrapolated"
			assert.Contains(tb, []string{"counted", "extrapolated"}, v.Str())
		case notInSpanAttrName1:
			assert.Fail(tb, notInSpanAttrName1+" should not be in this metric")
		default:
			assert.Equal(tb, wantDimensions[k], v)
			delete(wantDimensions, k)
		}
	}
	assert.Empty(tb, wantDimensions, "Did not see all expected dimensions in metric. Missing: ", wantDimensions)

	// Service/name/kind should be a unique metric.
	assert.False(tb, seenMetricIDs[mID])
	seenMetricIDs[mID] = true
}

func buildBadSampleTrace() ptrace.Traces {
	badTrace := buildSampleTrace()
	span := badTrace.ResourceSpans().At(0).ScopeSpans().At(0).Spans().At(0)
	now := time.Now()
	// Flipping timestamp for a bad duration
	span.SetEndTimestamp(pcommon.NewTimestampFromTime(now))
	span.SetStartTimestamp(
		pcommon.NewTimestampFromTime(now.Add(sampleDuration)),
	)
	return badTrace
}

// buildSampleTrace builds the following trace:
//
//	service-a/ping (server) ->
//	  service-a/ping (client) ->
//	    service-b/ping (server)
func buildSampleTrace() ptrace.Traces {
	traces := ptrace.NewTraces()

	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
				},
				{
					name:       "/ping",
					kind:       ptrace.SpanKindClient,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10},
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(
		serviceSpans{
			serviceName: "service-b",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
					traceID:    [16]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(serviceSpans{}, traces.ResourceSpans().AppendEmpty())
	return traces
}

// buildTraceWithUnsetStatusCode builds the following trace:
//
//	service-c/ping (server)
func appendTraceWithUnsetStatusCode(traces ptrace.Traces) ptrace.Traces {
	initServiceSpans(
		serviceSpans{
			serviceName: "service-c",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeUnset,
					traceID:    [16]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20},
					spanID:     [8]byte{0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28},
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)
	return traces
}

func initServiceSpans(serviceSpans serviceSpans, spans ptrace.ResourceSpans) {
	if serviceSpans.serviceName != "" {
		spans.Resource().Attributes().PutStr("service.name", serviceSpans.serviceName)
	}

	spans.Resource().Attributes().PutStr(regionResourceAttrName, sampleRegion)

	ils := spans.ScopeSpans().AppendEmpty()
	for _, span := range serviceSpans.spans {
		initSpan(span, ils.Spans().AppendEmpty())
	}
}

func initSpan(span span, s ptrace.Span) {
	s.SetName(span.name)
	s.SetKind(span.kind)
	s.Status().SetCode(span.statusCode)
	now := time.Now()
	s.SetStartTimestamp(pcommon.NewTimestampFromTime(now))
	s.SetEndTimestamp(
		pcommon.NewTimestampFromTime(now.Add(sampleDuration)),
	)

	s.Attributes().PutStr(stringAttrName, "stringAttrValue")
	s.Attributes().PutInt(intAttrName, 99)
	s.Attributes().PutDouble(doubleAttrName, 99.99)
	s.Attributes().PutBool(boolAttrName, true)
	s.Attributes().PutEmpty(nullAttrName)
	s.Attributes().PutEmptyMap(mapAttrName)
	s.Attributes().PutEmptySlice(arrayAttrName)
	s.SetTraceID(span.traceID)
	s.SetSpanID(span.spanID)

	if span.tracestate != "" {
		s.TraceState().FromRaw(span.tracestate)
	}

	e := s.Events().AppendEmpty()
	e.SetName("exception")
	e.Attributes().PutStr(exceptionTypeAttrName, "NullPointerException")
}

func setSpanAttributeValue(traces ptrace.Traces, key, value string) {
	for i := 0; i < traces.ResourceSpans().Len(); i++ {
		scopeSpans := traces.ResourceSpans().At(i).ScopeSpans()
		for j := 0; j < scopeSpans.Len(); j++ {
			spans := scopeSpans.At(j).Spans()
			for k := 0; k < spans.Len(); k++ {
				spans.At(k).Attributes().PutStr(key, value)
			}
		}
	}
}

func hasDataPointWithStringAttrValue(metrics pmetric.Metrics, value string) bool {
	for i := 0; i < metrics.ResourceMetrics().Len(); i++ {
		scopeMetrics := metrics.ResourceMetrics().At(i).ScopeMetrics()
		for j := 0; j < scopeMetrics.Len(); j++ {
			metricSlice := scopeMetrics.At(j).Metrics()
			for k := 0; k < metricSlice.Len(); k++ {
				metric := metricSlice.At(k)
				switch metric.Type() {
				case pmetric.MetricTypeSum:
					dps := metric.Sum().DataPoints()
					for l := 0; l < dps.Len(); l++ {
						attr, ok := dps.At(l).Attributes().Get(stringAttrName)
						if ok && attr.Str() == value {
							return true
						}
					}
				case pmetric.MetricTypeHistogram:
					dps := metric.Histogram().DataPoints()
					for l := 0; l < dps.Len(); l++ {
						attr, ok := dps.At(l).Attributes().Get(stringAttrName)
						if ok && attr.Str() == value {
							return true
						}
					}
				case pmetric.MetricTypeExponentialHistogram:
					dps := metric.ExponentialHistogram().DataPoints()
					for l := 0; l < dps.Len(); l++ {
						attr, ok := dps.At(l).Attributes().Get(stringAttrName)
						if ok && attr.Str() == value {
							return true
						}
					}
				}
			}
		}
	}
	return false
}

func disabledExemplarsConfig() ExemplarsConfig {
	return ExemplarsConfig{
		Enabled: false,
	}
}

func enabledExemplarsConfig() ExemplarsConfig {
	return ExemplarsConfig{
		Enabled:         true,
		MaxPerDataPoint: defaultMaxPerDatapoint,
	}
}

func enabledEventsConfig() EventsConfig {
	return EventsConfig{
		Enabled:    true,
		Dimensions: []Dimension{{Name: "exception.type"}},
	}
}

func disabledEventsConfig() EventsConfig {
	return EventsConfig{
		Enabled: false,
	}
}

func explicitHistogramsConfig() HistogramConfig {
	return HistogramConfig{
		Unit: defaultUnit,
		Explicit: configoptional.Some(ExplicitHistogramConfig{
			Buckets: []time.Duration{4 * time.Second, 6 * time.Second, 8 * time.Second},
		}),
	}
}

func exponentialHistogramsConfig() HistogramConfig {
	return HistogramConfig{
		Unit: defaultUnit,
		Exponential: configoptional.Some(ExponentialHistogramConfig{
			MaxSize: 10,
		}),
	}
}

func disabledHistogramsConfig() HistogramConfig {
	return HistogramConfig{
		Unit:    defaultUnit,
		Disable: true,
	}
}

func newConnectorImp(defaultNullValue *string, histogramConfig func() HistogramConfig, exemplarsConfig func() ExemplarsConfig, eventsConfig func() EventsConfig, temporality string, expiration time.Duration, resourceMetricsKeyAttributes []string, deltaTimestampCacheSize int, clock clockwork.Clock, enableMetricsSamplingMethod bool, excludedDimensions ...string) (*connectorImp, error) {
	cfg := &Config{
		AggregationTemporality:       temporality,
		Histogram:                    histogramConfig(),
		Exemplars:                    exemplarsConfig(),
		ExcludeDimensions:            excludedDimensions,
		ResourceMetricsCacheSize:     resourceMetricsCacheSize,
		ResourceMetricsKeyAttributes: resourceMetricsKeyAttributes,
		EnableMetricsSamplingMethod:  enableMetricsSamplingMethod,
		Dimensions: []Dimension{
			// Set nil defaults to force a lookup for the attribute in the span.
			{Name: stringAttrName, Default: nil},
			{Name: intAttrName, Default: nil},
			{Name: doubleAttrName, Default: nil},
			{Name: boolAttrName, Default: nil},
			{Name: mapAttrName, Default: nil},
			{Name: arrayAttrName, Default: nil},
			{Name: nullAttrName, Default: defaultNullValue},
			// Add a default value for an attribute that doesn't exist in a span
			{Name: notInSpanAttrName0, Default: stringp("defaultNotInSpanAttrVal")},
			// Leave the default value unset to test that this dimension should not be added to the metric.
			{Name: notInSpanAttrName1, Default: nil},
			// Add a resource attribute to test "process" attributes like IP, host, region, cluster, etc.
			{Name: regionResourceAttrName, Default: nil},
		},
		Events:               eventsConfig(),
		MetricsExpiration:    expiration,
		TimestampCacheSize:   &deltaTimestampCacheSize,
		MetricsFlushInterval: time.Nanosecond,
	}

	c, err := newConnector(zap.NewNop(), cfg, clock, instanceID)
	if err != nil {
		return nil, err
	}
	c.metricsConsumer = consumertest.NewNop()
	return c, nil
}

func stringp(str string) *string {
	return &str
}

func TestBuildKeySameServiceNameCharSequence(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)
	c, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	require.NoError(t, err)

	span0 := ptrace.NewSpan()
	span0.SetName("c")
	k0 := c.buildKey("ab", span0, dimensionList{}, dimensionList{}, pcommon.NewMap(), false)

	span1 := ptrace.NewSpan()
	span1.SetName("bc")
	k1 := c.buildKey("a", span1, dimensionList{}, dimensionList{}, pcommon.NewMap(), false)

	assert.NotEqual(t, k0, k1)
	assert.Equal(t, metrics.Key("ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET"), k0)
	assert.Equal(t, metrics.Key("a\u0000bc\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET"), k1)
}

func TestBuildKeyExcludeDimensionsAll(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)
	cfg.ExcludeDimensions = []string{"span.kind", "service.name", "span.name", "status.code"}
	c, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	require.NoError(t, err)

	span0 := ptrace.NewSpan()
	span0.SetName("spanName")
	k0 := c.buildKey("serviceName", span0, dimensionList{}, dimensionList{}, pcommon.NewMap(), false)
	assert.Equal(t, metrics.Key(""), k0)
}

func TestBuildKeyExcludeWrongDimensions(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)
	cfg.ExcludeDimensions = []string{"span.kind", "service.name.wrong.name", "span.name", "status.code"}
	c, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	require.NoError(t, err)

	span0 := ptrace.NewSpan()
	span0.SetName("spanName")
	k0 := c.buildKey("serviceName", span0, dimensionList{}, dimensionList{}, pcommon.NewMap(), false)
	assert.Equal(t, metrics.Key("serviceName"), k0)
}

func TestBuildKeyWithDimensions(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)
	c, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	require.NoError(t, err)

	defaultFoo := pcommon.NewValueStr("bar")
	for _, tc := range []struct {
		name            string
		optionalDims    dimensionList
		resourceAttrMap map[string]any
		spanAttrMap     map[string]any
		wantKey         string
	}{
		{
			name:    "nil optionalDims",
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET",
		},
		{
			name: "neither span nor resource contains key, dim provides default",
			optionalDims: dimensionList{nameDimensions: []pdatautil.Dimension{
				{Name: "foo", Value: &defaultFoo},
			}},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET\u0000foo:bar",
		},
		{
			name: "neither span nor resource contains key, dim provides no default",
			optionalDims: dimensionList{nameDimensions: []pdatautil.Dimension{
				{Name: "foo"},
			}},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET",
		},
		{
			name: "span attribute contains dimension",
			optionalDims: dimensionList{nameDimensions: []pdatautil.Dimension{
				{Name: "foo"},
			}},
			spanAttrMap: map[string]any{
				"foo": 99,
			},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET\u0000foo:99",
		},
		{
			name: "resource attribute contains dimension",
			optionalDims: dimensionList{nameDimensions: []pdatautil.Dimension{
				{Name: "foo"},
			}},
			resourceAttrMap: map[string]any{
				"foo": 99,
			},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET\u0000foo:99",
		},
		{
			name: "both span and resource attribute contains dimension, should prefer span attribute",
			optionalDims: dimensionList{nameDimensions: []pdatautil.Dimension{
				{Name: "foo"},
			}},
			spanAttrMap: map[string]any{
				"foo": 100,
			},
			resourceAttrMap: map[string]any{
				"foo": 99,
			},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET\u0000foo:100",
		},
		{
			name: "name and glob dimensions match attributes at both span and resource",
			optionalDims: dimensionList{
				nameDimensions: []pdatautil.Dimension{{Name: "http.method"}},
				globDimensions: []glob.Glob{glob.MustCompile("db.*")},
			},
			spanAttrMap: map[string]any{
				"http.method": "GET",
				"http.status": "200",
				"db.system":   "postgres",
			},
			resourceAttrMap: map[string]any{
				"db.name": "users",
			},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET\u0000http.method:GET\u0000db.system:postgres\u0000db.name:users",
		},
		{
			name:         "span attribute wins over resource attribute on the same glob-matched key",
			optionalDims: dimensionList{globDimensions: []glob.Glob{glob.MustCompile("env")}},
			spanAttrMap: map[string]any{
				"env": "prod",
			},
			resourceAttrMap: map[string]any{
				"env": "dev",
			},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET\u0000env:prod",
		},
		{
			name:         "no matching attribute: glob contributes nothing",
			optionalDims: dimensionList{globDimensions: []glob.Glob{glob.MustCompile("db.*")}},
			spanAttrMap: map[string]any{
				"http.method": "GET",
			},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET",
		},
		{
			name: "two globs match signle attribute, single value added",
			optionalDims: dimensionList{
				globDimensions: []glob.Glob{
					glob.MustCompile("db.*"),
					glob.MustCompile("*.name"),
				},
			},
			spanAttrMap: map[string]any{
				"db.name": "users",
			},
			wantKey: "ab\u0000c\u0000SPAN_KIND_UNSPECIFIED\u0000STATUS_CODE_UNSET\u0000db.name:users",
		},
	} {
		t.Run(tc.name, func(t *testing.T) {
			resAttr := pcommon.NewMap()
			assert.NoError(t, resAttr.FromRaw(tc.resourceAttrMap))
			span0 := ptrace.NewSpan()
			assert.NoError(t, span0.Attributes().FromRaw(tc.spanAttrMap))
			span0.SetName("c")
			key := c.buildKey("ab", span0, dimensionList{}, tc.optionalDims, resAttr, false)
			assert.Equal(t, metrics.Key(tc.wantKey), key)
		})
	}
}

func TestBuildAttributesWithDimensions(t *testing.T) {
	tests := []struct {
		name               string
		spanAttrMap        map[string]any
		resourceAttrMap    map[string]any
		dimensions         dimensionList
		optionalDimensions dimensionList
		want               map[string]string
	}{
		{
			name:        "no additional dimensions - common attributes only",
			spanAttrMap: map[string]any{},
			resourceAttrMap: map[string]any{
				"http.method": "GET",
				"http.status": 200,
				"db.name":     "test",
				"db.system":   "postgres",
				"env":         "dev",
			},
			dimensions:         dimensionList{},
			optionalDimensions: dimensionList{},
			want: map[string]string{
				serviceNameKey:       "test_service",
				spanNameKey:          "test_span",
				spanKindKey:          "SPAN_KIND_INTERNAL",
				statusCodeKey:        "STATUS_CODE_UNSET",
				collectorInstanceKey: instanceID,
			},
		},
		{
			name:        "named dimension added",
			spanAttrMap: map[string]any{},
			resourceAttrMap: map[string]any{
				"http.method": "GET",
				"http.status": 200,
				"db.name":     "test",
				"db.system":   "postgres",
				"env":         "dev",
			},
			dimensions: dimensionList{
				nameDimensions: []pdatautil.Dimension{{Name: "http.method"}},
			},
			optionalDimensions: dimensionList{},
			want: map[string]string{
				serviceNameKey:       "test_service",
				spanNameKey:          "test_span",
				spanKindKey:          "SPAN_KIND_INTERNAL",
				statusCodeKey:        "STATUS_CODE_UNSET",
				collectorInstanceKey: instanceID,
				"http.method":        "GET",
			},
		},
		{
			name:        "named dimension and glob dimensions added",
			spanAttrMap: map[string]any{},
			resourceAttrMap: map[string]any{
				"http.method": "GET",
				"http.status": 200,
				"db.name":     "test",
				"db.system":   "postgres",
				"env":         "dev",
			},
			dimensions: dimensionList{
				nameDimensions: []pdatautil.Dimension{{Name: "http.method"}},
				globDimensions: []glob.Glob{glob.MustCompile("db.*")},
			},
			optionalDimensions: dimensionList{},
			want: map[string]string{
				serviceNameKey:       "test_service",
				spanNameKey:          "test_span",
				spanKindKey:          "SPAN_KIND_INTERNAL",
				statusCodeKey:        "STATUS_CODE_UNSET",
				collectorInstanceKey: instanceID,
				"http.method":        "GET",
				"db.name":            "test",
				"db.system":          "postgres",
			},
		},
		{
			name:        "both common and optional dimensions are added",
			spanAttrMap: map[string]any{},
			resourceAttrMap: map[string]any{
				"http.method": "GET",
				"http.status": 200,
				"db.name":     "test",
				"db.system":   "postgres",
				"env":         "dev",
			},
			dimensions: dimensionList{
				nameDimensions: []pdatautil.Dimension{{Name: "http.method"}},
				globDimensions: []glob.Glob{glob.MustCompile("db.*")},
			},
			optionalDimensions: dimensionList{
				nameDimensions: []pdatautil.Dimension{{Name: "http.status"}},
				globDimensions: []glob.Glob{glob.MustCompile("env")},
			},
			want: map[string]string{
				serviceNameKey:       "test_service",
				spanNameKey:          "test_span",
				spanKindKey:          "SPAN_KIND_INTERNAL",
				statusCodeKey:        "STATUS_CODE_UNSET",
				collectorInstanceKey: instanceID,
				"http.method":        "GET",
				"http.status":        "200",
				"db.name":            "test",
				"db.system":          "postgres",
				"env":                "dev",
			},
		},
		{
			name: "span attributes precede resource attributes",
			spanAttrMap: map[string]any{
				"env": "prod",
			},
			resourceAttrMap: map[string]any{
				"http.method": "GET",
				"http.status": 200,
				"db.name":     "test",
				"db.system":   "postgres",
				"env":         "dev",
			},
			dimensions: dimensionList{
				nameDimensions: []pdatautil.Dimension{{Name: "env"}},
			},
			optionalDimensions: dimensionList{},
			want: map[string]string{
				serviceNameKey:       "test_service",
				spanNameKey:          "test_span",
				spanKindKey:          "SPAN_KIND_INTERNAL",
				statusCodeKey:        "STATUS_CODE_UNSET",
				collectorInstanceKey: instanceID,
				"env":                "prod",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &connectorImp{config: Config{}, instanceID: instanceID}

			span := ptrace.NewSpan()
			span.SetName("test_span")
			span.SetKind(ptrace.SpanKindInternal)
			assert.NoError(t, span.Attributes().FromRaw(tt.spanAttrMap))
			resAttr := pcommon.NewMap()
			assert.NoError(t, resAttr.FromRaw(tt.resourceAttrMap))

			attrs := p.buildAttributes("test_service", span, resAttr, tt.dimensions, tt.optionalDimensions, pcommon.NewInstrumentationScope(), false)
			assert.Equal(t, len(tt.want), attrs.Len())
			for k, v := range tt.want {
				val, ok := attrs.Get(k)
				assert.True(t, ok)
				assert.Equal(t, v, val.AsString())
			}
		})
	}
}

func TestStart(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)

	createParams := connectortest.NewNopSettings(factory.Type())
	conn, err := factory.CreateTracesToMetrics(t.Context(), createParams, cfg, consumertest.NewNop())
	require.NoError(t, err)

	smc := conn.(*connectorImp)
	ctx := t.Context()
	err = smc.Start(ctx, componenttest.NewNopHost())
	defer func() { sdErr := smc.Shutdown(ctx); require.NoError(t, sdErr) }()
	assert.NoError(t, err)
}

func TestConcurrentShutdown(t *testing.T) {
	// Prepare
	ctx := t.Context()
	core, observedLogs := observer.New(zapcore.InfoLevel)

	// Test
	p, err := newConnectorImp(nil, explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
	require.NoError(t, err)
	// Override the default no-op consumer and logger for testing.
	p.metricsConsumer = new(consumertest.MetricsSink)
	p.logger = zap.New(core)
	err = p.Start(ctx, componenttest.NewNopHost())
	require.NoError(t, err)

	// Allow goroutines time to start.
	time.Sleep(time.Millisecond)

	// Simulate many goroutines trying to concurrently shutdown.
	var wg sync.WaitGroup
	const concurrency = 1000
	wg.Add(concurrency)
	for range concurrency {
		go func() {
			err := p.Shutdown(ctx)
			assert.NoError(t, err)
			wg.Done()
		}()
	}
	wg.Wait()

	// Allow time for log observer to sync all logs emitted.
	// Even though the WaitGroup has been given the "done" signal, there's still a potential race condition
	// between the WaitGroup being unblocked and when the logs will be flushed.
	var allLogs []observer.LoggedEntry
	assert.Eventually(t, func() bool {
		allLogs = observedLogs.All()
		return len(allLogs) > 0
	}, time.Second, time.Millisecond*10)

	// Starting spanmetricsconnector...
	// Shutting down spanmetricsconnector...
	// Stopping ticker.
	assert.Len(t, allLogs, 3)
}

func TestConnectorCapabilities(t *testing.T) {
	// Prepare
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)

	// Test
	c, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	// Override the default no-op consumer for testing.
	c.metricsConsumer = new(consumertest.MetricsSink)
	assert.NoError(t, err)
	caps := c.Capabilities()

	// Verify
	assert.NotNil(t, c)
	assert.False(t, caps.MutatesData)
}

type errConsumer struct {
	wg      *sync.WaitGroup
	fakeErr error
}

func (*errConsumer) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

func (e *errConsumer) ConsumeMetrics(context.Context, pmetric.Metrics) error {
	e.wg.Done()
	return e.fakeErr
}

func TestConsumeMetricsErrors(t *testing.T) {
	// Prepare
	fakeErr := errors.New("consume metrics error")

	core, observedLogs := observer.New(zapcore.ErrorLevel)
	logger := zap.New(core)

	var wg sync.WaitGroup
	mockClock := clockwork.NewFakeClock()
	p, err := newConnectorImp(nil, explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, mockClock, false)
	require.NoError(t, err)
	// Override the default no-op consumer and logger for testing.
	p.metricsConsumer = &errConsumer{
		wg:      &wg,
		fakeErr: fakeErr,
	}
	p.logger = logger

	ctx := metadata.NewIncomingContext(t.Context(), nil)
	err = p.Start(ctx, componenttest.NewNopHost())
	defer func() { sdErr := p.Shutdown(ctx); require.NoError(t, sdErr) }()
	require.NoError(t, err)

	traces := buildSampleTrace()

	// Test
	err = p.ConsumeTraces(ctx, traces)
	require.NoError(t, err)

	// Trigger flush.
	wg.Add(1)
	mockClock.Advance(time.Nanosecond)
	wg.Wait()

	// Allow time for log observer to sync all logs emitted.
	// Even though the WaitGroup has been given the "done" signal, there's still a potential race condition
	// between the WaitGroup being unblocked and when the logs will be flushed.
	var allLogs []observer.LoggedEntry
	assert.Eventually(t, func() bool {
		allLogs = observedLogs.All()
		return len(allLogs) > 0
	}, time.Second, time.Millisecond*10)

	assert.Equal(t, "Failed ConsumeMetrics", allLogs[0].Message)
}

func TestConsumeTraces(t *testing.T) {
	// enable it
	require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsExcludeResourceMetricsFeatureGate.ID(), true))
	defer func() {
		require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsLegacyMetricNamesFeatureGate.ID(), false))
	}()

	t.Parallel()

	testcases := []struct {
		name                   string
		aggregationTemporality string
		histogramConfig        func() HistogramConfig
		exemplarConfig         func() ExemplarsConfig
		verifier               func(tb testing.TB, input pmetric.Metrics) bool
		traces                 []ptrace.Traces
		statusCodeFeatureGate  bool
	}{
		// disabling histogram
		{
			name:                   "Test histogram metrics are disabled",
			aggregationTemporality: cumulative,
			histogramConfig:        disabledHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyDisabledHistogram,
			traces:                 []ptrace.Traces{buildSampleTrace()},
		},
		// exponential buckets histogram
		{
			name:                   "Test single consumption, three spans (Cumulative), using exp. histogram",
			aggregationTemporality: cumulative,
			histogramConfig:        exponentialHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyConsumeMetricsInputCumulative,
			traces:                 []ptrace.Traces{buildSampleTrace()},
		},
		{
			name:                   "Test single consumption, three spans (Delta), using exp. histogram",
			aggregationTemporality: delta,
			histogramConfig:        exponentialHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyConsumeMetricsInputDelta,
			traces:                 []ptrace.Traces{buildSampleTrace()},
		},
		{
			// More consumptions, should accumulate additively.
			name:                   "Test two consumptions (Cumulative), using exp. histogram",
			aggregationTemporality: cumulative,
			histogramConfig:        exponentialHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyMultipleCumulativeConsumptions(),
			traces:                 []ptrace.Traces{buildSampleTrace(), buildSampleTrace()},
		},
		{
			// More consumptions, should not accumulate. Therefore, end state should be the same as single consumption case.
			name:                   "Test two consumptions (Delta), using exp. histogram",
			aggregationTemporality: delta,
			histogramConfig:        exponentialHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyConsumeMetricsInputDelta,
			traces:                 []ptrace.Traces{buildSampleTrace(), buildSampleTrace()},
		},
		{
			// Consumptions with improper timestamps
			name:                   "Test bad consumptions (Delta), using exp. histogram",
			aggregationTemporality: cumulative,
			histogramConfig:        exponentialHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyBadMetricsOkay,
			traces:                 []ptrace.Traces{buildBadSampleTrace()},
		},
		{
			// Test that the status code is set properly
			name:                   "Test using new status code attribute",
			aggregationTemporality: delta,
			histogramConfig:        exponentialHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyOtelStatusCode,
			traces:                 []ptrace.Traces{appendTraceWithUnsetStatusCode(buildSampleTrace())},
			statusCodeFeatureGate:  true,
		},

		// explicit buckets histogram
		{
			name:                   "Test single consumption, three spans (Cumulative).",
			aggregationTemporality: cumulative,
			histogramConfig:        explicitHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyConsumeMetricsInputCumulative,
			traces:                 []ptrace.Traces{buildSampleTrace()},
		},
		{
			name:                   "Test single consumption, three spans (Delta).",
			aggregationTemporality: delta,
			histogramConfig:        explicitHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyConsumeMetricsInputDelta,
			traces:                 []ptrace.Traces{buildSampleTrace()},
		},
		{
			// More consumptions, should accumulate additively.
			name:                   "Test two consumptions (Cumulative).",
			aggregationTemporality: cumulative,
			histogramConfig:        explicitHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyMultipleCumulativeConsumptions(),
			traces:                 []ptrace.Traces{buildSampleTrace(), buildSampleTrace()},
		},
		{
			// More consumptions, should not accumulate. Therefore, end state should be the same as single consumption case.
			name:                   "Test two consumptions (Delta).",
			aggregationTemporality: delta,
			histogramConfig:        explicitHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyConsumeMetricsInputDelta,
			traces:                 []ptrace.Traces{buildSampleTrace(), buildSampleTrace()},
		},
		{
			// Consumptions with improper timestamps
			name:                   "Test bad consumptions (Delta).",
			aggregationTemporality: cumulative,
			histogramConfig:        explicitHistogramsConfig,
			exemplarConfig:         disabledExemplarsConfig,
			verifier:               verifyBadMetricsOkay,
			traces:                 []ptrace.Traces{buildBadSampleTrace()},
		},
		// enabling exemplars
		{
			name:                   "Test Exemplars are enabled",
			aggregationTemporality: cumulative,
			histogramConfig:        explicitHistogramsConfig,
			exemplarConfig:         enabledExemplarsConfig,
			verifier:               verifyExemplarsExist,
			traces:                 []ptrace.Traces{buildSampleTrace()},
		},
	}

	for _, tc := range testcases {
		t.Run(tc.name, func(t *testing.T) {
			// Prepare

			mcon := &consumertest.MetricsSink{}
			mockClock := clockwork.NewFakeClock()
			p, err := newConnectorImp(stringp("defaultNullValue"), tc.histogramConfig, tc.exemplarConfig, disabledEventsConfig, tc.aggregationTemporality, 0, []string{}, 1000, mockClock, false)
			require.NoError(t, err)
			// Override the default no-op consumer with metrics sink for testing.
			p.metricsConsumer = mcon
			if tc.statusCodeFeatureGate {
				require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.SpanmetricsStatusCodeConventionUseOtelPrefixFeatureGate.ID(), true))
				defer func() {
					require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.SpanmetricsStatusCodeConventionUseOtelPrefixFeatureGate.ID(), false))
				}()
			}

			ctx := metadata.NewIncomingContext(t.Context(), nil)
			err = p.Start(ctx, componenttest.NewNopHost())
			defer func() { sdErr := p.Shutdown(ctx); require.NoError(t, sdErr) }()
			require.NoError(t, err)

			for _, traces := range tc.traces {
				// Test
				err = p.ConsumeTraces(ctx, traces)
				assert.NoError(t, err)

				// Trigger flush.
				mockClock.Advance(time.Nanosecond)
				// TODO: Remove time.Sleep call, see https://github.com/open-telemetry/opentelemetry-collector-contrib/issues/42461
				time.Sleep(10 * time.Millisecond)
				require.Eventually(t, func() bool {
					return len(mcon.AllMetrics()) > 0
				}, 1*time.Second, 10*time.Millisecond)
				tc.verifier(t, mcon.AllMetrics()[len(mcon.AllMetrics())-1])
			}
		})
	}
}

func TestCallsMetricsInitialise(t *testing.T) {
	traces := buildSampleTrace()

	p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
	require.NoError(t, err)

	ctx := metadata.NewIncomingContext(t.Context(), nil)
	err = p.Start(ctx, componenttest.NewNopHost())
	defer func() { sdErr := p.Shutdown(ctx); require.NoError(t, sdErr) }()
	require.NoError(t, err)

	err = p.ConsumeTraces(ctx, traces)
	assert.NoError(t, err)

	verifyDataPointValue := func(t *testing.T, pmetrics pmetric.Metrics, value int64) {
		assert.NotNil(t, pmetrics)
		require.NotEmpty(t, pmetrics.ResourceMetrics().Len())
		rm := pmetrics.ResourceMetrics().At(0)
		require.NotEmpty(t, rm.ScopeMetrics().Len())
		sm := rm.ScopeMetrics().At(0)
		require.NotEmpty(t, sm.Metrics().Len())
		m := sm.Metrics().At(0)
		require.NotEmpty(t, m.Sum().DataPoints().Len())
		dp := m.Sum().DataPoints().At(0)
		require.Equal(t, value, dp.IntValue())
	}

	// first call buildMetrics(), it will emit zero value
	pmetrics := p.buildMetrics()
	verifyDataPointValue(t, pmetrics, 0)

	// second call buildMetrics(), it will emit actual value
	pmetrics = p.buildMetrics()
	verifyDataPointValue(t, pmetrics, 1)
}

func TestResourceMetricsCache(t *testing.T) {
	p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
	require.NoError(t, err)

	// Test
	ctx := metadata.NewIncomingContext(t.Context(), nil)

	// 0 resources in the beginning
	assert.Zero(t, p.resourceMetrics.Len())

	err = p.ConsumeTraces(ctx, buildSampleTrace())
	// Validate
	require.NoError(t, err)
	assert.Equal(t, 2, p.resourceMetrics.Len())

	// consume another batch of traces for the same resources
	err = p.ConsumeTraces(ctx, buildSampleTrace())
	require.NoError(t, err)
	assert.Equal(t, 2, p.resourceMetrics.Len())

	// consume more batches for new resources. Max size is exceeded causing old resource entries to be discarded
	for i := range resourceMetricsCacheSize {
		traces := buildSampleTrace()

		// add resource attributes to simulate additional resources providing data
		for j := 0; j < traces.ResourceSpans().Len(); j++ {
			traces.ResourceSpans().At(j).Resource().Attributes().PutStr("dummy", fmt.Sprintf("%d", i))
		}

		err = p.ConsumeTraces(ctx, traces)
		require.NoError(t, err)
	}

	// validate that the cache doesn't grow past its limit
	assert.Equal(t, resourceMetricsCacheSize, p.resourceMetrics.Len())
}

func TestResourceMetricsExpiration(t *testing.T) {
	p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 1*time.Millisecond, []string{}, 1000, clockwork.NewFakeClock(), false)
	require.NoError(t, err)

	// Test
	ctx := metadata.NewIncomingContext(t.Context(), nil)

	// 0 resources in the beginning
	assert.Zero(t, p.resourceMetrics.Len())

	err = p.ConsumeTraces(ctx, buildSampleTrace())
	// Validate
	require.NoError(t, err)
	assert.Equal(t, 2, p.resourceMetrics.Len())

	// consume another batch of traces for the same resources
	err = p.ConsumeTraces(ctx, buildSampleTrace())
	require.NoError(t, err)
	assert.Equal(t, 2, p.resourceMetrics.Len())
}

func TestSeriesExpiration(t *testing.T) {
	mockClock := clockwork.NewFakeClock()
	p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, mockClock, false)
	require.NoError(t, err)
	p.config.SeriesExpiration = time.Millisecond

	ctx := metadata.NewIncomingContext(t.Context(), nil)

	tracesA := buildSampleTrace()
	setSpanAttributeValue(tracesA, stringAttrName, "A")

	tracesB := buildSampleTrace()
	setSpanAttributeValue(tracesB, stringAttrName, "B")

	require.NoError(t, p.ConsumeTraces(ctx, tracesA))
	exported := p.buildMetrics()
	assert.True(t, hasDataPointWithStringAttrValue(exported, "A"))
	assert.False(t, hasDataPointWithStringAttrValue(exported, "B"))
	p.resetState()

	mockClock.Advance(time.Millisecond)

	require.NoError(t, p.ConsumeTraces(ctx, tracesB))
	exported = p.buildMetrics()
	assert.True(t, hasDataPointWithStringAttrValue(exported, "A"))
	assert.True(t, hasDataPointWithStringAttrValue(exported, "B"))
	p.resetState()

	exported = p.buildMetrics()
	assert.False(t, hasDataPointWithStringAttrValue(exported, "A"))
	assert.True(t, hasDataPointWithStringAttrValue(exported, "B"))
}

func TestResourceMetricsKeyAttributes(t *testing.T) {
	resourceMetricsKeyAttributes := []string{
		"service.name",
	}

	p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, resourceMetricsKeyAttributes, 1000, clockwork.NewFakeClock(), false)
	require.NoError(t, err)

	// Test
	ctx := metadata.NewIncomingContext(t.Context(), nil)

	// 0 resources in the beginning
	assert.Zero(t, p.resourceMetrics.Len())

	err = p.ConsumeTraces(ctx, buildSampleTrace())
	// Validate
	require.NoError(t, err)
	assert.Equal(t, 2, p.resourceMetrics.Len())

	// consume another batch of traces for the same resources
	err = p.ConsumeTraces(ctx, buildSampleTrace())
	require.NoError(t, err)
	assert.Equal(t, 2, p.resourceMetrics.Len())

	// consume more batches for new resources. Max size is exceeded causing old resource entries to be discarded
	for i := range resourceMetricsCacheSize {
		traces := buildSampleTrace()

		// add resource attributes to simulate additional resources providing data
		for j := 0; j < traces.ResourceSpans().Len(); j++ {
			traces.ResourceSpans().At(j).Resource().Attributes().PutStr("not included in resource key attributes", fmt.Sprintf("%d", i))
		}

		err = p.ConsumeTraces(ctx, traces)
		require.NoError(t, err)
	}

	// validate that the additional resources providing data did not result in additional resource metrics
	assert.Equal(t, 2, p.resourceMetrics.Len())
}

func TestAddResourceAttributesConfig(t *testing.T) {
	tests := []struct {
		name                     string
		addResourceAttributes    bool
		featureGateEnabled       bool
		expectResourceAttributes bool
	}{
		{
			name:                     "feature gate disabled, config false - should include resource attributes",
			addResourceAttributes:    false,
			featureGateEnabled:       false,
			expectResourceAttributes: true,
		},
		{
			name:                     "feature gate enabled, config false - should exclude resource attributes",
			addResourceAttributes:    false,
			featureGateEnabled:       true,
			expectResourceAttributes: false,
		},
		{
			name:                     "feature gate enabled, config true - should include resource attributes (override)",
			addResourceAttributes:    true,
			featureGateEnabled:       true,
			expectResourceAttributes: true,
		},
		{
			name:                     "feature gate disabled, config true - should include resource attributes",
			addResourceAttributes:    true,
			featureGateEnabled:       false,
			expectResourceAttributes: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Save and restore the feature gate state
			previousValue := spanmetricsmetadata.ConnectorSpanmetricsExcludeResourceMetricsFeatureGate.IsEnabled()
			require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsExcludeResourceMetricsFeatureGate.ID(), tt.featureGateEnabled))
			defer func() {
				require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsExcludeResourceMetricsFeatureGate.ID(), previousValue))
			}()

			// Create a custom config with AddResourceAttributes
			cfg := &Config{
				AggregationTemporality:       cumulative,
				Histogram:                    explicitHistogramsConfig(),
				Exemplars:                    disabledExemplarsConfig(),
				Events:                       disabledEventsConfig(),
				ResourceMetricsCacheSize:     resourceMetricsCacheSize,
				ResourceMetricsKeyAttributes: []string{},
				Dimensions:                   []Dimension{},
				MetricsFlushInterval:         time.Nanosecond,
				AddResourceAttributes:        tt.addResourceAttributes,
			}

			p, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
			require.NoError(t, err)
			p.metricsConsumer = consumertest.NewNop()

			// Create a trace with resource attributes
			traces := ptrace.NewTraces()
			rs := traces.ResourceSpans().AppendEmpty()
			rs.Resource().Attributes().PutStr("service.name", "test-service")
			rs.Resource().Attributes().PutStr("test.resource.attr", "test-value")
			rs.Resource().Attributes().PutStr(regionResourceAttrName, sampleRegion)

			ils := rs.ScopeSpans().AppendEmpty()
			span := ils.Spans().AppendEmpty()
			span.SetName("/test")
			span.SetKind(ptrace.SpanKindServer)
			span.SetTraceID([16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10})
			span.SetSpanID([8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18})
			span.SetStartTimestamp(pcommon.NewTimestampFromTime(time.Now()))
			span.SetEndTimestamp(pcommon.NewTimestampFromTime(time.Now().Add(sampleDuration)))

			// Consume the traces
			ctx := metadata.NewIncomingContext(t.Context(), nil)
			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)

			// Build metrics and verify
			m := p.buildMetrics()
			require.Equal(t, 1, m.ResourceMetrics().Len())

			rm := m.ResourceMetrics().At(0)
			resourceAttrs := rm.Resource().Attributes()

			if tt.expectResourceAttributes {
				// Should have resource attributes
				assert.Positive(t, resourceAttrs.Len(), "Expected resource attributes to be present")
				val, ok := resourceAttrs.Get("service.name")
				assert.True(t, ok, "Expected service.name attribute to be present")
				assert.Equal(t, "test-service", val.Str())
				val, ok = resourceAttrs.Get("test.resource.attr")
				assert.True(t, ok, "Expected test.resource.attr attribute to be present")
				assert.Equal(t, "test-value", val.Str())
			} else {
				// Should not have resource attributes
				assert.Equal(t, 0, resourceAttrs.Len(), "Expected no resource attributes")
			}
		})
	}
}

func BenchmarkConnectorConsumeTraces(b *testing.B) {
	// Prepare
	conn, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
	require.NoError(b, err)

	traces := buildSampleTrace()

	// Test
	ctx := metadata.NewIncomingContext(b.Context(), nil)
	for b.Loop() {
		assert.NoError(b, conn.ConsumeTraces(ctx, traces))
	}
}

func TestExcludeDimensionsConsumeTraces(t *testing.T) {
	testcases := []struct {
		dsc                string
		featureGateEnabled bool
	}{
		{
			dsc:                fmt.Sprintf("%s enabled", spanmetricsmetadata.ConnectorSpanmetricsLegacyMetricNamesFeatureGate.ID()),
			featureGateEnabled: true,
		},
		{
			dsc:                fmt.Sprintf("%s disabled", spanmetricsmetadata.ConnectorSpanmetricsLegacyMetricNamesFeatureGate.ID()),
			featureGateEnabled: false,
		},
	}

	excludeDimensions := []string{"span.kind", "span.name", "totallyWrongNameDoesNotAffectAnything"}
	for _, tc := range testcases {
		t.Run(tc.dsc, func(t *testing.T) {
			// Set feature gate value
			previousValue := spanmetricsmetadata.ConnectorSpanmetricsLegacyMetricNamesFeatureGate.IsEnabled()
			require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsLegacyMetricNamesFeatureGate.ID(), tc.featureGateEnabled))
			defer func() {
				require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsLegacyMetricNamesFeatureGate.ID(), previousValue))
			}()

			p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false, excludeDimensions...)
			require.NoError(t, err)
			traces := buildSampleTrace()

			ctx := metadata.NewIncomingContext(t.Context(), nil)

			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)
			metrics := p.buildMetrics()

			for i := 0; i < metrics.ResourceMetrics().Len(); i++ {
				rm := metrics.ResourceMetrics().At(i)
				ism := rm.ScopeMetrics()
				// Checking all metrics, naming notice: ilmC/mC - C here is for Counter.
				for ilmC := 0; ilmC < ism.Len(); ilmC++ {
					m := ism.At(ilmC).Metrics()
					for mC := 0; mC < m.Len(); mC++ {
						metric := m.At(mC)
						// We check only sum and histogram metrics here, because for now only they are present in this module.

						switch metric.Type() {
						case pmetric.MetricTypeExponentialHistogram, pmetric.MetricTypeHistogram:
							dp := metric.Histogram().DataPoints()
							for dpi := 0; dpi < dp.Len(); dpi++ {
								for attributeKey := range dp.At(dpi).Attributes().AsRaw() {
									assert.NotContains(t, excludeDimensions, attributeKey)
								}
							}
						case pmetric.MetricTypeEmpty, pmetric.MetricTypeGauge, pmetric.MetricTypeSum, pmetric.MetricTypeSummary:
							dp := metric.Sum().DataPoints()
							for dpi := 0; dpi < dp.Len(); dpi++ {
								for attributeKey := range dp.At(dpi).Attributes().AsRaw() {
									assert.NotContains(t, excludeDimensions, attributeKey)
								}
							}
						}
					}
				}
			}
		})
	}
}

func TestConnectorConsumeTracesEvictedCacheKey(t *testing.T) {
	// Prepare
	traces0 := ptrace.NewTraces()

	initServiceSpans(
		serviceSpans{
			// This should be moved to the evicted list of the LRU cache once service-c is added
			// since the cache size is configured to 2.
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
				},
			},
		}, traces0.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(
		serviceSpans{
			serviceName: "service-b",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
				},
			},
		}, traces0.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(
		serviceSpans{
			serviceName: "service-c",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
				},
			},
		}, traces0.ResourceSpans().AppendEmpty(),
	)

	// This trace does not have service-a, and may not result in an attempt to publish metrics for
	// service-a because service-a may be removed from the metricsKeyCache's evicted list.
	traces1 := ptrace.NewTraces()

	initServiceSpans(
		serviceSpans{
			serviceName: "service-b",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
				},
			},
		}, traces1.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(
		serviceSpans{
			serviceName: "service-c",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
				},
			},
		}, traces1.ResourceSpans().AppendEmpty(),
	)

	mcon := &consumertest.MetricsSink{}

	wantDataPointCounts := []int{
		6, // (calls + duration) * (service-a + service-b + service-c)
		4, // (calls + duration) * (service-b + service-c)
	}

	// Ensure the assertion that wantDataPointCounts is performed only after all ConsumeMetrics
	// invocations are complete.
	var wg sync.WaitGroup
	wg.Add(len(wantDataPointCounts))

	// Note: default dimension key cache size is 2.
	mockClock := clockwork.NewFakeClock()
	p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, mockClock, false)
	require.NoError(t, err)
	// Override the default no-op consumer with metrics sink for testing.
	p.metricsConsumer = mcon

	ctx := metadata.NewIncomingContext(t.Context(), nil)
	err = p.Start(ctx, componenttest.NewNopHost())
	defer func() { sdErr := p.Shutdown(ctx); require.NoError(t, sdErr) }()
	require.NoError(t, err)

	for _, traces := range []ptrace.Traces{traces0, traces1} {
		// Test
		err = p.ConsumeTraces(ctx, traces)
		require.NoError(t, err)

		// Allow time for metrics aggregation to complete.
		time.Sleep(time.Millisecond)

		// Trigger flush.
		mockClock.Advance(time.Nanosecond)

		// Allow time for metrics flush to complete.
		time.Sleep(time.Millisecond)
	}

	require.Eventually(t, func() bool {
		return len(mcon.AllMetrics()) == len(wantDataPointCounts)
	}, 1*time.Second, 10*time.Millisecond)

	// Verify
	require.NotEmpty(t, wantDataPointCounts)

	for i, wanted := range wantDataPointCounts {
		// GreaterOrEqual is particularly necessary for the second assertion where we
		// expect 4 data points; but could also be 6 due to the non-deterministic nature
		// of the p.histograms map which, through the act of "Get"ting a cached key, will
		// lead to updating its recent-ness.
		require.GreaterOrEqual(t, mcon.AllMetrics()[i].DataPointCount(), wanted)
	}
}

func TestConnectorConsumeTracesExpiredMetrics(t *testing.T) {
	t.Skip("flaky test: https://github.com/open-telemetry/opentelemetry-collector-contrib/issues/37096")
	// Prepare
	traces0 := ptrace.NewTraces()

	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
				},
			},
		}, traces0.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(
		serviceSpans{
			serviceName: "service-b",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
				},
			},
		}, traces0.ResourceSpans().AppendEmpty(),
	)

	traces1 := ptrace.NewTraces()

	initServiceSpans(
		serviceSpans{
			serviceName: "service-x",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
				},
			},
		}, traces1.ResourceSpans().AppendEmpty(),
	)

	mcon := &consumertest.MetricsSink{}

	// Creating a connector with a very short metricsTTL to ensure that the metrics are expired.
	mockClock := clockwork.NewFakeClock()
	p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 1*time.Nanosecond, []string{}, 1000, mockClock, false)
	require.NoError(t, err)
	// Override the default no-op consumer with metrics sink for testing.
	p.metricsConsumer = mcon

	ctx := metadata.NewIncomingContext(t.Context(), nil)
	err = p.Start(ctx, componenttest.NewNopHost())
	defer func() { sdErr := p.Shutdown(ctx); require.NoError(t, sdErr) }()
	require.NoError(t, err)

	// Test expiration by sending three batches of traces, with the second and third batch being identical.
	// On firsts test run, we should see only data points for traces #0 (= 4 data points)
	// On second test run, we want to see both data points for traces #0 and #1 (= 6 data points)
	// On third test run, we want to see only data points for traces #1, since metrics for traces #0 should be expired (= 2 data points)
	wantedDataPointCounts := []int{4, 6, 2}
	for i, traces := range []ptrace.Traces{traces0, traces1, traces1} {
		// Test
		err = p.ConsumeTraces(ctx, traces)
		require.NoError(t, err)

		// Allow time for metrics aggregation to complete.
		time.Sleep(time.Millisecond)

		// Trigger flush.
		mockClock.Advance(time.Nanosecond)

		// Allow time for metrics flush to complete.
		time.Sleep(time.Millisecond)

		// Verify.
		require.Equal(t, wantedDataPointCounts[i], mcon.AllMetrics()[0].DataPointCount())

		// Reset so we can verify the next set of metrics from scratch.
		mcon.Reset()
	}
}

func TestBuildMetricName(t *testing.T) {
	tests := []struct {
		namespace  string
		metricName string
		expected   string
	}{
		{"", "metric", "metric"},
		{"ns", "metric", "ns.metric"},
		{"longer_namespace", "metric", "longer_namespace.metric"},
	}

	for _, test := range tests {
		actual := buildMetricName(test.namespace, test.metricName)
		assert.Equal(t, test.expected, actual)
	}
}

func TestConnector_durationsToUnits(t *testing.T) {
	tests := []struct {
		input []time.Duration
		unit  metrics.Unit
		want  []float64
	}{
		{
			input: []time.Duration{
				3 * time.Nanosecond,
				3 * time.Microsecond,
				3 * time.Millisecond,
				3 * time.Second,
			},
			unit: defaultUnit,
			want: []float64{3e-09, 3e-06, 0.003, 3},
		},
		{
			input: []time.Duration{
				3 * time.Nanosecond,
				3 * time.Microsecond,
				3 * time.Millisecond,
				3 * time.Second,
			},
			unit: metrics.Seconds,
			want: []float64{3e-09, 3e-06, 0.003, 3},
		},
		{
			input: []time.Duration{},
			unit:  defaultUnit,
			want:  []float64{},
		},
	}
	for _, tt := range tests {
		t.Run("", func(t *testing.T) {
			got := durationsToUnits(tt.input, unitDivider(tt.unit))
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestConnector_initHistogramMetrics(t *testing.T) {
	defaultHistogramBucketsSeconds := make([]float64, len(defaultHistogramBucketsMs))
	for i, v := range defaultHistogramBucketsMs {
		defaultHistogramBucketsSeconds[i] = v / 1000
	}

	tests := []struct {
		name   string
		config Config
		want   metrics.HistogramMetrics
	}{
		{
			name:   "initialize histogram with no config provided",
			config: Config{},
			want:   metrics.NewExplicitHistogramMetrics(defaultHistogramBucketsMs, 0, 0),
		},
		{
			name: "Disable histogram",
			config: Config{
				Histogram: HistogramConfig{
					Disable: true,
				},
			},
			want: nil,
		},
		{
			name: "initialize explicit histogram with default bounds (ms)",
			config: Config{
				Histogram: HistogramConfig{
					Unit: metrics.Milliseconds,
				},
			},
			want: metrics.NewExplicitHistogramMetrics(defaultHistogramBucketsMs, 0, 0),
		},
		{
			name: "initialize explicit histogram with default bounds (seconds)",
			config: Config{
				Histogram: HistogramConfig{
					Unit: metrics.Seconds,
				},
			},
			want: metrics.NewExplicitHistogramMetrics(defaultHistogramBucketsSeconds, 0, 0),
		},
		{
			name: "initialize explicit histogram with bounds (seconds)",
			config: Config{
				Histogram: HistogramConfig{
					Unit: metrics.Seconds,
					Explicit: configoptional.Some(ExplicitHistogramConfig{
						Buckets: []time.Duration{
							100 * time.Millisecond,
							1000 * time.Millisecond,
						},
					}),
				},
			},
			want: metrics.NewExplicitHistogramMetrics([]float64{0.1, 1}, 0, 0),
		},
		{
			name: "initialize explicit histogram with bounds (ms)",
			config: Config{
				Histogram: HistogramConfig{
					Unit: metrics.Milliseconds,
					Explicit: configoptional.Some(ExplicitHistogramConfig{
						Buckets: []time.Duration{
							100 * time.Millisecond,
							1000 * time.Millisecond,
						},
					}),
				},
			},
			want: metrics.NewExplicitHistogramMetrics([]float64{100, 1000}, 0, 0),
		},
		{
			name: "initialize exponential histogram",
			config: Config{
				Histogram: HistogramConfig{
					Unit: metrics.Milliseconds,
					Exponential: configoptional.Some(ExponentialHistogramConfig{
						MaxSize: 10,
					}),
				},
			},
			want: metrics.NewExponentialHistogramMetrics(10, 0, 0),
		},
		{
			name: "initialize exponential histogram with default max buckets count",
			config: Config{
				Histogram: HistogramConfig{
					Unit:        metrics.Milliseconds,
					Exponential: configoptional.Some(ExponentialHistogramConfig{}),
				},
			},
			want: metrics.NewExponentialHistogramMetrics(structure.DefaultMaxSize, 0, 0),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := initHistogramMetrics(tt.config)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestSpanMetrics_Events(t *testing.T) {
	tests := []struct {
		name                    string
		eventsConfig            EventsConfig
		shouldEventsMetricExist bool
	}{
		{
			name:                    "events disabled",
			eventsConfig:            EventsConfig{Enabled: false, Dimensions: []Dimension{{Name: "exception.type", Default: stringp("NullPointerException")}}},
			shouldEventsMetricExist: false,
		},
		{
			name:                    "events enabled",
			eventsConfig:            EventsConfig{Enabled: true, Dimensions: []Dimension{{Name: "exception.type", Default: stringp("NullPointerException")}}},
			shouldEventsMetricExist: true,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			factory := NewFactory()
			cfg := factory.CreateDefaultConfig().(*Config)
			cfg.Events = tt.eventsConfig
			c, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
			require.NoError(t, err)
			err = c.ConsumeTraces(t.Context(), buildSampleTrace())
			require.NoError(t, err)
			metrics := c.buildMetrics()
			for i := 0; i < metrics.ResourceMetrics().Len(); i++ {
				rm := metrics.ResourceMetrics().At(i)
				ism := rm.ScopeMetrics()
				for ilmC := 0; ilmC < ism.Len(); ilmC++ {
					m := ism.At(ilmC).Metrics()
					if !tt.shouldEventsMetricExist {
						assert.Equal(t, 2, m.Len())
						continue
					}
					assert.Equal(t, 3, m.Len())
					for mC := 0; mC < m.Len(); mC++ {
						metric := m.At(mC)
						if metric.Name() != "events" {
							continue
						}
						assert.Equal(t, pmetric.MetricTypeSum, metric.Type())
						for idp := 0; idp < metric.Sum().DataPoints().Len(); idp++ {
							attrs := metric.Sum().DataPoints().At(idp).Attributes()
							assert.Contains(t, attrs.AsRaw(), exceptionTypeAttrName)
						}
					}
				}
			}
		})
	}
}

func TestExemplarsAreDiscardedAfterFlushing(t *testing.T) {
	tests := []struct {
		name            string
		temporality     string
		histogramConfig func() HistogramConfig
	}{
		{
			name:            "cumulative explicit histogram",
			temporality:     cumulative,
			histogramConfig: explicitHistogramsConfig,
		},
		{
			name:            "cumulative exponential histogram",
			temporality:     cumulative,
			histogramConfig: exponentialHistogramsConfig,
		},
		{
			name:            "delta explicit histogram",
			temporality:     delta,
			histogramConfig: explicitHistogramsConfig,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p, err := newConnectorImp(stringp("defaultNullValue"), tt.histogramConfig, enabledExemplarsConfig, enabledEventsConfig, tt.temporality, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
			p.metricsConsumer = &consumertest.MetricsSink{}
			require.NoError(t, err)

			traces := ptrace.NewTraces()
			trace1ID := [16]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10}
			initServiceSpans(
				serviceSpans{
					serviceName: "service-b",
					spans: []span{
						{
							name:       "/ping",
							kind:       ptrace.SpanKindServer,
							statusCode: ptrace.StatusCodeError,
							traceID:    trace1ID,
							spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
						},
					},
				}, traces.ResourceSpans().AppendEmpty(),
			)

			// Test
			ctx := metadata.NewIncomingContext(t.Context(), nil)

			// Verify exactly 1 exemplar is added to all data points when flushing
			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)

			p.exportMetrics(ctx)
			m := p.metricsConsumer.(*consumertest.MetricsSink).AllMetrics()[0]
			assertDataPointsHaveExactlyOneExemplarForTrace(t, m, trace1ID)

			// Verify exemplars from previous batch's trace are replaced with exemplars for the new batch's trace
			traces = ptrace.NewTraces()
			trace2ID := [16]byte{0x00, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10}
			initServiceSpans(
				serviceSpans{
					serviceName: "service-b",
					spans: []span{
						{
							name:       "/ping",
							kind:       ptrace.SpanKindServer,
							statusCode: ptrace.StatusCodeError,
							traceID:    trace2ID,
							spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
						},
					},
				}, traces.ResourceSpans().AppendEmpty(),
			)

			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)

			p.exportMetrics(ctx)
			m = p.metricsConsumer.(*consumertest.MetricsSink).AllMetrics()[1]
			assertDataPointsHaveExactlyOneExemplarForTrace(t, m, trace2ID)
		})
	}
}

func assertDataPointsHaveExactlyOneExemplarForTrace(t *testing.T, metrics pmetric.Metrics, traceID pcommon.TraceID) {
	for i := 0; i < metrics.ResourceMetrics().Len(); i++ {
		rm := metrics.ResourceMetrics().At(i)
		ism := rm.ScopeMetrics()
		// Checking all metrics, naming notice: ilmC/mC - C here is for Counter.
		for ilmC := 0; ilmC < ism.Len(); ilmC++ {
			m := ism.At(ilmC).Metrics()
			for mC := 0; mC < m.Len(); mC++ {
				metric := m.At(mC)
				switch metric.Type() {
				case pmetric.MetricTypeSum:
					dps := metric.Sum().DataPoints()
					assert.Positive(t, dps.Len())
					for dpi := 0; dpi < dps.Len(); dpi++ {
						dp := dps.At(dpi)
						assert.Equal(t, 1, dp.Exemplars().Len())
						assert.Equal(t, dp.Exemplars().At(0).TraceID(), traceID)
					}
				case pmetric.MetricTypeHistogram:
					dps := metric.Histogram().DataPoints()
					assert.Positive(t, dps.Len())
					for dpi := 0; dpi < dps.Len(); dpi++ {
						dp := dps.At(dpi)
						assert.Equal(t, 1, dp.Exemplars().Len())
						assert.Equal(t, dp.Exemplars().At(0).TraceID(), traceID)
					}
				case pmetric.MetricTypeExponentialHistogram:
					dps := metric.ExponentialHistogram().DataPoints()
					assert.Positive(t, dps.Len())
					for dpi := 0; dpi < dps.Len(); dpi++ {
						dp := dps.At(dpi)
						assert.Equal(t, 1, dp.Exemplars().Len())
						assert.Equal(t, dp.Exemplars().At(0).TraceID(), traceID)
					}
				default:
					t.Fatalf("Unexpected metric type %s", metric.Type())
				}
			}
		}
	}
}

func TestTimestampsForUninterruptedStream(t *testing.T) {
	// enable it
	require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsExcludeResourceMetricsFeatureGate.ID(), true))
	defer func() {
		require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsLegacyMetricNamesFeatureGate.ID(), false))
	}()

	tests := []struct {
		temporality      string
		verifyTimestamps func(startTime1, timestamp1, startTime2, timestamp2 pcommon.Timestamp)
	}{
		{
			temporality: cumulative,
			verifyTimestamps: func(startTime1, timestamp1, startTime2, timestamp2 pcommon.Timestamp) {
				// (T1, T2), (T1, T3) ...
				assert.Greater(t, timestamp1, startTime1)
				assert.Equal(t, startTime1, startTime2)
				assert.Greater(t, timestamp2, startTime2)
			},
		},
		{
			temporality: delta,
			verifyTimestamps: func(startTime1, timestamp1, startTime2, timestamp2 pcommon.Timestamp) {
				// (T1, T2), (T2, T3) ...
				assert.Greater(t, timestamp1, startTime1)
				assert.Equal(t, timestamp1, startTime2)
				assert.Greater(t, timestamp2, startTime2)
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.temporality, func(t *testing.T) {
			mockClock := newAlwaysIncreasingClock()
			p, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, enabledExemplarsConfig, enabledEventsConfig, tt.temporality, 0, []string{}, 1000, mockClock, false)
			require.NoError(t, err)
			p.metricsConsumer = &consumertest.MetricsSink{}

			// Test
			ctx := metadata.NewIncomingContext(t.Context(), nil)

			// Send first batch of spans
			err = p.ConsumeTraces(ctx, buildSampleTrace())
			require.NoError(t, err)
			p.exportMetrics(ctx)
			metrics1 := p.metricsConsumer.(*consumertest.MetricsSink).AllMetrics()[0]
			startTimestamp1, timestamp1 := verifyAndCollectCommonTimestamps(t, metrics1)

			// Send an unrelated batch of spans for a different resource
			unrelatedTraces := ptrace.NewTraces()
			initServiceSpans(
				serviceSpans{
					serviceName: "unrelated-service",
					spans: []span{
						{
							name:       "/ping",
							kind:       ptrace.SpanKindServer,
							statusCode: ptrace.StatusCodeOk,
							traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
							spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
						},
					},
				}, unrelatedTraces.ResourceSpans().AppendEmpty(),
			)
			err = p.ConsumeTraces(ctx, unrelatedTraces)
			require.NoError(t, err)
			p.exportMetrics(ctx)

			// Send another set of spans that are the same as the first batch
			err = p.ConsumeTraces(ctx, buildSampleTrace())
			require.NoError(t, err)
			p.exportMetrics(ctx)
			metrics2 := p.metricsConsumer.(*consumertest.MetricsSink).AllMetrics()[2]
			startTimestamp2, timestamp2 := verifyAndCollectCommonTimestamps(t, metrics2)

			tt.verifyTimestamps(startTimestamp1, timestamp1, startTimestamp2, timestamp2)
		})
	}
}

func verifyAndCollectCommonTimestamps(t *testing.T, m pmetric.Metrics) (start, timestamp pcommon.Timestamp) {
	// Go through all data points and collect the start timestamp and timestamp. They should be the same value for each data point
	for i := 0; i < m.ResourceMetrics().Len(); i++ {
		rm := m.ResourceMetrics().At(i)

		serviceName, _ := rm.ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0).Attributes().Get("service.name")
		if serviceName.Str() == "unrelated-service" {
			continue
		}

		ism := rm.ScopeMetrics()
		for ilmC := 0; ilmC < ism.Len(); ilmC++ {
			m := ism.At(ilmC).Metrics()
			for mC := 0; mC < m.Len(); mC++ {
				metric := m.At(mC)

				switch metric.Type() {
				case pmetric.MetricTypeSum:
					dps := metric.Sum().DataPoints()
					for dpi := 0; dpi < dps.Len(); dpi++ {
						if int64(start) == 0 {
							start = dps.At(dpi).StartTimestamp()
							timestamp = dps.At(dpi).Timestamp()
						}
						assert.Equal(t, dps.At(dpi).StartTimestamp(), start)
						assert.Equal(t, dps.At(dpi).Timestamp(), timestamp)
					}
				case pmetric.MetricTypeHistogram:
					dps := metric.Histogram().DataPoints()
					for dpi := 0; dpi < dps.Len(); dpi++ {
						if int64(start) == 0 {
							start = dps.At(dpi).StartTimestamp()
							timestamp = dps.At(dpi).Timestamp()
						}
						assert.Equal(t, dps.At(dpi).StartTimestamp(), start)
						assert.Equal(t, dps.At(dpi).Timestamp(), timestamp)
					}
				default:
					t.Fail()
				}
			}
		}
	}

	return start, timestamp
}

func TestDeltaTimestampCacheExpiry(t *testing.T) {
	timestampCacheSize := 1
	mockClock := newAlwaysIncreasingClock()
	p, err := newConnectorImp(stringp("defaultNullValue"), exponentialHistogramsConfig, enabledExemplarsConfig, enabledEventsConfig, delta, 0, []string{}, timestampCacheSize, mockClock, false)
	require.NoError(t, err)
	p.metricsConsumer = &consumertest.MetricsSink{}

	ctx := metadata.NewIncomingContext(t.Context(), nil)

	// Send a span from service A which should fill the cache
	serviceATrace1 := ptrace.NewTraces()
	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
				},
			},
		}, serviceATrace1.ResourceSpans().AppendEmpty(),
	)
	err = p.ConsumeTraces(ctx, serviceATrace1)
	require.NoError(t, err)
	p.exportMetrics(ctx)

	// Send a span from service B which should evict service A's entries
	serviceBTrace1 := ptrace.NewTraces()
	initServiceSpans(
		serviceSpans{
			serviceName: "service-b",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
				},
			},
		}, serviceBTrace1.ResourceSpans().AppendEmpty(),
	)
	err = p.ConsumeTraces(ctx, serviceBTrace1)
	require.NoError(t, err)
	p.exportMetrics(ctx)

	// Send another span from Service A, then verify no error + cache was actually evicted
	serviceATrace2 := ptrace.NewTraces()
	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
				},
			},
		}, serviceATrace2.ResourceSpans().AppendEmpty(),
	)
	err = p.ConsumeTraces(ctx, serviceATrace2)
	require.NoError(t, err)
	p.exportMetrics(ctx)

	serviceATimestamp1 := p.metricsConsumer.(*consumertest.MetricsSink).AllMetrics()[0].ResourceMetrics().At(0).ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0).Timestamp()
	serviceAStartTimestamp2 := p.metricsConsumer.(*consumertest.MetricsSink).AllMetrics()[2].ResourceMetrics().At(0).ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0).StartTimestamp()
	assert.Greater(t, serviceAStartTimestamp2, serviceATimestamp1) // These would be the same if nothing was evicted from the cache
}

func TestSeparateDimensions(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)
	cfg.Namespace = ""
	cfg.Dimensions = []Dimension{{Name: stringAttrName, Default: nil}}
	cfg.CallsDimensions = []Dimension{{Name: intAttrName, Default: stringp("0")}}
	cfg.Histogram.Dimensions = []Dimension{{Name: doubleAttrName, Default: stringp("0.0")}}
	c, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	require.NoError(t, err)
	err = c.ConsumeTraces(t.Context(), buildSampleTrace())
	require.NoError(t, err)
	metrics := c.buildMetrics()
	for i := 0; i < metrics.ResourceMetrics().Len(); i++ {
		rm := metrics.ResourceMetrics().At(i)
		ism := rm.ScopeMetrics()
		for ilmC := 0; ilmC < ism.Len(); ilmC++ {
			m := ism.At(ilmC).Metrics()
			for mC := 0; mC < m.Len(); mC++ {
				metric := m.At(mC)
				if metric.Name() == metricNameCalls {
					assert.Equal(t, pmetric.MetricTypeSum, metric.Type())
					for idp := 0; idp < metric.Sum().DataPoints().Len(); idp++ {
						attrs := metric.Sum().DataPoints().At(idp).Attributes()
						assert.Contains(t, attrs.AsRaw(), stringAttrName)
						assert.Contains(t, attrs.AsRaw(), intAttrName) // only in traces.span.metrics.calls metric
					}
				}
				if metric.Name() == metricNameDuration {
					assert.Equal(t, pmetric.MetricTypeHistogram, metric.Type())
					for idp := 0; idp < metric.Histogram().DataPoints().Len(); idp++ {
						attrs := metric.Histogram().DataPoints().At(idp).Attributes()
						assert.Contains(t, attrs.AsRaw(), stringAttrName)
						assert.Contains(t, attrs.AsRaw(), doubleAttrName) // only in traces.span.metrics.duration
					}
				}
			}
		}
	}
}

// Clock where Now() always returns a greater value than the previous return value
type alwaysIncreasingClock struct {
	clockwork.Clock
}

func newAlwaysIncreasingClock() alwaysIncreasingClock {
	return alwaysIncreasingClock{
		Clock: clockwork.NewFakeClock(),
	}
}

func (c alwaysIncreasingClock) Now() time.Time {
	c.Clock.(*clockwork.FakeClock).Advance(time.Millisecond)
	return c.Clock.Now()
}

func TestBuildAttributes_InstrumentationScope(t *testing.T) {
	tests := []struct {
		name                 string
		instrumentationScope pcommon.InstrumentationScope
		config               Config
		want                 map[string]string
	}{
		{
			name: "with instrumentation scope name and version",
			instrumentationScope: func() pcommon.InstrumentationScope {
				scope := pcommon.NewInstrumentationScope()
				scope.SetName("express")
				scope.SetVersion("1.0.0")
				return scope
			}(),
			config: Config{
				IncludeInstrumentationScope: []string{"express"},
				EnableMetricsSamplingMethod: true,
			},
			want: map[string]string{
				serviceNameKey:                 "test_service",
				spanNameKey:                    "test_span",
				spanKindKey:                    "SPAN_KIND_INTERNAL",
				statusCodeKey:                  "STATUS_CODE_UNSET",
				instrumentationScopeNameKey:    "express",
				instrumentationScopeVersionKey: "1.0.0",
				collectorInstanceKey:           instanceID,
			},
		},
		{
			name: "with instrumentation scope but not included",
			instrumentationScope: func() pcommon.InstrumentationScope {
				scope := pcommon.NewInstrumentationScope()
				scope.SetName("express")
				scope.SetVersion("1.0.0")
				return scope
			}(),
			config: Config{EnableMetricsSamplingMethod: true},
			want: map[string]string{
				serviceNameKey:       "test_service",
				spanNameKey:          "test_span",
				spanKindKey:          "SPAN_KIND_INTERNAL",
				statusCodeKey:        "STATUS_CODE_UNSET",
				collectorInstanceKey: instanceID,
			},
		},
		{
			name: "without instrumentation scope but version and included in config",
			instrumentationScope: func() pcommon.InstrumentationScope {
				scope := pcommon.NewInstrumentationScope()
				scope.SetVersion("1.0.0")
				return scope
			}(),
			config: Config{
				IncludeInstrumentationScope: []string{"express"},
				EnableMetricsSamplingMethod: true,
			},
			want: map[string]string{
				serviceNameKey:       "test_service",
				spanNameKey:          "test_span",
				spanKindKey:          "SPAN_KIND_INTERNAL",
				statusCodeKey:        "STATUS_CODE_UNSET",
				collectorInstanceKey: instanceID,
			},
		},

		{
			name: "with instrumentation scope and instrumentation scope name but no version and included in config",
			instrumentationScope: func() pcommon.InstrumentationScope {
				scope := pcommon.NewInstrumentationScope()
				scope.SetName("express")
				return scope
			}(),
			config: Config{
				IncludeInstrumentationScope: []string{"express"},
				EnableMetricsSamplingMethod: true,
			},
			want: map[string]string{
				serviceNameKey:              "test_service",
				spanNameKey:                 "test_span",
				spanKindKey:                 "SPAN_KIND_INTERNAL",
				statusCodeKey:               "STATUS_CODE_UNSET",
				instrumentationScopeNameKey: "express",
				collectorInstanceKey:        instanceID,
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &connectorImp{config: tt.config, instanceID: instanceID}

			span := ptrace.NewSpan()
			span.SetName("test_span")
			span.SetKind(ptrace.SpanKindInternal)

			attrs := p.buildAttributes("test_service", span, pcommon.NewMap(), dimensionList{}, dimensionList{}, tt.instrumentationScope, false)

			// +1 for the sampling.method attribute when enabled
			assert.Equal(t, len(tt.want)+1, attrs.Len())
			for k, v := range tt.want {
				val, ok := attrs.Get(k)
				assert.True(t, ok)
				assert.Equal(t, v, val.Str())
			}
			// Verify sampling.method attribute is present
			samplingMethod, ok := attrs.Get(metricAttrSamplingMethod)
			assert.True(t, ok)
			assert.Equal(t, "counted", samplingMethod.Str())
		})
	}
}

func TestConnectorWithCardinalityLimit(t *testing.T) {
	cfg := createDefaultConfig().(*Config)
	cfg.AggregationCardinalityLimit = 2
	cfg.Dimensions = []Dimension{
		{Name: "region"},
	}

	connector, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	require.NoError(t, err)

	require.NotNil(t, connector)

	// Create two different resources
	resource1 := pcommon.NewResource()
	resource1.Attributes().PutStr("service.name", "service1")
	resource1.Attributes().PutStr("region", "us-east-1")

	resource2 := pcommon.NewResource()
	resource2.Attributes().PutStr("service.name", "service2")
	resource2.Attributes().PutStr("region", "us-west-1")

	// Create spans for the resources
	traces := ptrace.NewTraces()

	rspan1 := traces.ResourceSpans().AppendEmpty()
	resource1.CopyTo(rspan1.Resource())
	ils1 := rspan1.ScopeSpans().AppendEmpty()

	rspan2 := traces.ResourceSpans().AppendEmpty()
	resource2.CopyTo(rspan2.Resource())
	ils2 := rspan2.ScopeSpans().AppendEmpty()

	// Add spans with different names to trigger overflow
	for i := range 5 {
		span1 := ils1.Spans().AppendEmpty()
		span1.SetName(fmt.Sprintf("operation%d", i))
		span1.SetKind(ptrace.SpanKindServer)
		span1.Attributes().PutStr("http.method", "GET")

		span2 := ils2.Spans().AppendEmpty()
		span2.SetName(fmt.Sprintf("operation%d", i))
		span2.SetKind(ptrace.SpanKindServer)
		span2.Attributes().PutStr("http.method", "GET")
	}

	// Send two batches of spans to the connector to ensure it consumes more spans data,
	// avoiding potential edge-case traps.
	assert.NoError(t, connector.ConsumeTraces(t.Context(), traces))
	assert.NoError(t, connector.ConsumeTraces(t.Context(), traces))

	// Ignore the first buildMetrics call, which emits zero datapoint values.
	_ = connector.buildMetrics()

	pmetrics := connector.buildMetrics()
	rmetrics := pmetrics.ResourceMetrics()
	assert.Equal(t, 2, rmetrics.Len()) // 2 ResourceMetrics

	for i := 0; i < rmetrics.Len(); i++ {
		rm := rmetrics.At(i)
		serviceName, _ := rm.Resource().Attributes().Get("service.name")

		// Each resource should have:
		// - 2 normal metrics (under limit)
		// - 1 overflow metric
		metricCount := 0
		overflowCount := 0

		assert.Equal(t, 1, rm.ScopeMetrics().Len()) //  one ScopeMetrics
		metricsSlice := rm.ScopeMetrics().At(0).Metrics()
		for j := 0; j < metricsSlice.Len(); j++ {
			metric := metricsSlice.At(j)
			if metric.Name() == buildMetricName(DefaultNamespace, metricNameCalls) {
				dps := metric.Sum().DataPoints()
				assert.Equal(t, 3, dps.Len()) // three DataPoints
				for k := 0; k < dps.Len(); k++ {
					dp := dps.At(k)
					if _, exists := dp.Attributes().Get(overflowKey); exists {
						overflowCount++
						attrs := dp.Attributes()
						overflowVal, exists := attrs.Get(overflowKey)
						assert.True(t, exists)
						assert.True(t, overflowVal.Bool())
						assert.Equal(t, int64(6), dp.IntValue()) // overflow datapoints have value of 6
					} else {
						metricCount++
						attrs := dp.Attributes()
						_, exists := attrs.Get(serviceNameKey)
						assert.True(t, exists)
						_, exists = attrs.Get(spanNameKey)
						assert.True(t, exists)
						_, exists = attrs.Get(spanKindKey)
						assert.True(t, exists)
						_, exists = attrs.Get(statusCodeKey)
						assert.True(t, exists)
						_, exists = attrs.Get("region")
						assert.True(t, exists)
						assert.Equal(t, int64(2), dp.IntValue()) // normal datapoints have value of 2
					}
				}
			}
			if metric.Name() == buildMetricName(DefaultNamespace, metricNameDuration) {
				dps := metric.Histogram().DataPoints()
				assert.Equal(t, 3, dps.Len()) // three DataPoints
				for k := 0; k < dps.Len(); k++ {
					assert.Equal(t, 3, dps.Len()) // three DataPoints
					for k := 0; k < dps.Len(); k++ {
						dp := dps.At(k)
						if _, exists := dp.Attributes().Get(overflowKey); exists {
							attrs := dp.Attributes()
							overflowVal, exists := attrs.Get(overflowKey)
							assert.True(t, exists)
							assert.True(t, overflowVal.Bool())
							assert.Equal(t, uint64(6), dp.Count()) // overflow datapoints have value of 6
						} else {
							attrs := dp.Attributes()
							_, exists := attrs.Get(serviceNameKey)
							assert.True(t, exists)
							_, exists = attrs.Get(spanNameKey)
							assert.True(t, exists)
							_, exists = attrs.Get(spanKindKey)
							assert.True(t, exists)
							_, exists = attrs.Get(statusCodeKey)
							assert.True(t, exists)
							_, exists = attrs.Get("region")
							assert.True(t, exists)
							assert.Equal(t, uint64(2), dp.Count()) // normal datapoints have value of 2
						}
					}
				}
			}
		}

		assert.Equal(t, 2, metricCount, "service %s: expected 2 normal metrics. Found: %d", serviceName.Str(), metricCount)
		assert.Equal(t, 1, overflowCount, "service %s: expected 1 overflow metric. Found: %d", serviceName.Str(), overflowCount)
	}
}

func TestConnectorWithCardinalityLimitForEvents(t *testing.T) {
	cfg := createDefaultConfig().(*Config)
	cfg.AggregationCardinalityLimit = 2
	cfg.Events.Enabled = true
	cfg.Dimensions = []Dimension{
		{Name: "event.name"},
	}

	connector, err := newConnector(zaptest.NewLogger(t), cfg, clockwork.NewFakeClock(), instanceID)
	require.NoError(t, err)
	require.NotNil(t, connector)

	// Create a resource
	resource := pcommon.NewResource()
	resource.Attributes().PutStr("service.name", "service1")

	// Create traces with events
	traces := ptrace.NewTraces()
	rspan := traces.ResourceSpans().AppendEmpty()
	resource.CopyTo(rspan.Resource())
	ils := rspan.ScopeSpans().AppendEmpty()

	// Add a span with multiple events that will trigger overflow
	span := ils.Spans().AppendEmpty()
	span.SetName("operation1")
	span.SetKind(ptrace.SpanKindServer)

	// Add 3 different events to trigger overflow
	events := span.Events()
	for i := range 5 {
		event := events.AppendEmpty()
		event.SetName(fmt.Sprintf("event%d", i))
		event.Attributes().PutStr("event.name", fmt.Sprintf("event%d", i))
	}

	// Send two batches of spans to the connector to ensure it consumes more spans data,
	// avoiding potential edge-case traps.
	assert.NoError(t, connector.ConsumeTraces(t.Context(), traces))
	assert.NoError(t, connector.ConsumeTraces(t.Context(), traces))

	// Ignore the first buildMetrics call, which emits zero datapoint values.
	_ = connector.buildMetrics()
	pmetrics := connector.buildMetrics()

	rmetrics := pmetrics.ResourceMetrics()
	assert.Equal(t, 1, rmetrics.Len())

	rm := rmetrics.At(0)

	// Check events metric
	assert.Equal(t, 1, rm.ScopeMetrics().Len())
	metricsSlice := rm.ScopeMetrics().At(0).Metrics()
	var eventsMetric pmetric.Metric
	for i := 0; i < metricsSlice.Len(); i++ {
		if metricsSlice.At(i).Name() == buildMetricName(DefaultNamespace, metricNameEvents) {
			eventsMetric = metricsSlice.At(i)
			break
		}
	}
	require.NotNil(t, eventsMetric, "events metric not found")

	dps := eventsMetric.Sum().DataPoints()
	normalCount := 0
	overflowCount := 0

	for i := 0; i < dps.Len(); i++ {
		dp := dps.At(i)
		if _, exists := dp.Attributes().Get(overflowKey); exists {
			overflowCount++
			assert.Equal(t, int64(6), dp.IntValue())
		} else {
			normalCount++
			// Verify normal metric has event name
			attrs := dp.Attributes()
			_, exists = attrs.Get("event.name")
			assert.True(t, exists)
			_, exists = attrs.Get(serviceNameKey)
			assert.True(t, exists)
			_, exists = attrs.Get(spanNameKey)
			assert.True(t, exists)
			_, exists = attrs.Get(spanKindKey)
			assert.True(t, exists)
			_, exists = attrs.Get(statusCodeKey)
			assert.True(t, exists)
			assert.Equal(t, int64(2), dp.IntValue())
		}
	}

	assert.Equal(t, 2, normalCount, "expected 2 normal metrics")
	assert.Equal(t, 1, overflowCount, "expected 1 overflow metric")
}

func TestBuildAttributesWithFeatureGate(t *testing.T) {
	tests := []struct {
		name                       string
		instrumentationScope       pcommon.InstrumentationScope
		config                     Config
		want                       map[string]string
		includeCollectorInstanceID bool
	}{
		{
			name: "disable includeCollectorInstanceID feature-gate",
			instrumentationScope: func() pcommon.InstrumentationScope {
				scope := pcommon.NewInstrumentationScope()
				scope.SetName("express")
				scope.SetVersion("1.0.0")
				return scope
			}(),
			config: Config{
				IncludeInstrumentationScope: []string{"express"},
				EnableMetricsSamplingMethod: true,
			},
			want: map[string]string{
				serviceNameKey:                 "test_service",
				spanNameKey:                    "test_span",
				spanKindKey:                    "SPAN_KIND_INTERNAL",
				statusCodeKey:                  "STATUS_CODE_UNSET",
				instrumentationScopeNameKey:    "express",
				instrumentationScopeVersionKey: "1.0.0",
			},
			includeCollectorInstanceID: false,
		},
		{
			name: "enable includeCollectorInstanceID feature-gate",
			instrumentationScope: func() pcommon.InstrumentationScope {
				scope := pcommon.NewInstrumentationScope()
				scope.SetName("express")
				scope.SetVersion("1.0.0")
				return scope
			}(),
			config: Config{
				IncludeInstrumentationScope: []string{"express"},
				EnableMetricsSamplingMethod: true,
			},
			want: map[string]string{
				serviceNameKey:                 "test_service",
				spanNameKey:                    "test_span",
				spanKindKey:                    "SPAN_KIND_INTERNAL",
				statusCodeKey:                  "STATUS_CODE_UNSET",
				instrumentationScopeNameKey:    "express",
				instrumentationScopeVersionKey: "1.0.0",
				collectorInstanceKey:           instanceID,
			},
			includeCollectorInstanceID: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &connectorImp{config: tt.config, instanceID: instanceID}
			if !tt.includeCollectorInstanceID {
				require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsIncludeCollectorInstanceIDFeatureGate.ID(), false))
			}
			defer func() {
				require.NoError(t, featuregate.GlobalRegistry().Set(spanmetricsmetadata.ConnectorSpanmetricsIncludeCollectorInstanceIDFeatureGate.ID(), true))
			}()

			span := ptrace.NewSpan()
			span.SetName("test_span")
			span.SetKind(ptrace.SpanKindInternal)

			attrs := p.buildAttributes("test_service", span, pcommon.NewMap(), dimensionList{}, dimensionList{}, tt.instrumentationScope, false)

			// +1 for the sampling.method attribute that's always added
			assert.Equal(t, len(tt.want)+1, attrs.Len())
			for k, v := range tt.want {
				val, ok := attrs.Get(k)
				assert.True(t, ok)
				assert.Equal(t, v, val.Str())
			}
			// Verify sampling.method attribute is present
			samplingMethod, ok := attrs.Get(metricAttrSamplingMethod)
			assert.True(t, ok)
			assert.Equal(t, "counted", samplingMethod.Str())
		})
	}
}

func TestBuildAttributes_AdjustedCount(t *testing.T) {
	tests := []struct {
		name                 string
		enableSamplingMethod bool
		isAdjustedCount      bool
		expectAttribute      bool
		expectValue          string
	}{
		{
			name:                 "enabled and adjusted - attribute extrapolated",
			enableSamplingMethod: true,
			isAdjustedCount:      true,
			expectAttribute:      true,
			expectValue:          "extrapolated",
		},
		{
			name:                 "enabled and not adjusted - attribute counted",
			enableSamplingMethod: true,
			isAdjustedCount:      false,
			expectAttribute:      true,
			expectValue:          "counted",
		},
		{
			name:                 "disabled - attribute not present",
			enableSamplingMethod: false,
			isAdjustedCount:      false,
			expectAttribute:      false,
			expectValue:          "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &connectorImp{config: Config{EnableMetricsSamplingMethod: tt.enableSamplingMethod}}

			span := ptrace.NewSpan()
			span.SetName("test_span")
			span.SetKind(ptrace.SpanKindInternal)

			attrs := p.buildAttributes("test_service", span, pcommon.NewMap(), dimensionList{}, dimensionList{}, pcommon.NewInstrumentationScope(), tt.isAdjustedCount)

			val, ok := attrs.Get(metricAttrSamplingMethod)
			assert.Equal(t, tt.expectAttribute, ok, "sampling.method attribute presence")
			if tt.expectAttribute {
				assert.Equal(t, tt.expectValue, val.Str(), "sampling.method value")
			}
		})
	}
}

func TestAdjustedCountAttribute_Integration(t *testing.T) {
	// Test that spans with valid tracestate produce metrics with adjusted_count attribute
	// and spans without tracestate do not have the attribute

	tests := []struct {
		name           string
		tracestate     string
		expectAdjusted bool
	}{
		{
			name:           "span with valid tracestate th:c (25% sampling)",
			tracestate:     "ot=th:c",
			expectAdjusted: true,
		},
		{
			name:           "span with valid tracestate th:8 (50% sampling)",
			tracestate:     "ot=th:8",
			expectAdjusted: true,
		},
		{
			name:           "span without tracestate",
			tracestate:     "",
			expectAdjusted: false,
		},
		{
			name:           "span with tracestate but no th field",
			tracestate:     "ot=rv:abcdabcdabcdff",
			expectAdjusted: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p, err := newConnectorImp(nil, explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), true)
			require.NoError(t, err)

			ctx := metadata.NewIncomingContext(t.Context(), nil)
			err = p.Start(ctx, componenttest.NewNopHost())
			require.NoError(t, err)
			defer func() { require.NoError(t, p.Shutdown(ctx)) }()

			traces := buildSampleTraceWithTracestate(tt.tracestate)

			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)

			// First call buildMetrics() emits zero value, second call emits actual value
			_ = p.buildMetrics()
			receivedMetrics := p.buildMetrics()

			require.NotEmpty(t, receivedMetrics.ResourceMetrics().Len(), "should have resource metrics")

			// Find the sum metric (calls)
			found := false
			for i := 0; i < receivedMetrics.ResourceMetrics().Len(); i++ {
				rm := receivedMetrics.ResourceMetrics().At(i)
				for j := 0; j < rm.ScopeMetrics().Len(); j++ {
					sm := rm.ScopeMetrics().At(j)
					for k := 0; k < sm.Metrics().Len(); k++ {
						m := sm.Metrics().At(k)
						if m.Name() == metricNameCalls {
							require.Equal(t, pmetric.MetricTypeSum, m.Type())
							dps := m.Sum().DataPoints()
							for l := 0; l < dps.Len(); l++ {
								dp := dps.At(l)
								val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)

								assert.True(t, hasAttr, "sampling.method attribute should always be present")
								if tt.expectAdjusted {
									assert.Equal(t, "extrapolated", val.Str(), "sampling.method should be extrapolated for valid tracestate")
								} else {
									assert.Equal(t, "counted", val.Str(), "sampling.method should be counted for invalid/missing tracestate")
								}
								found = true
							}
						}
					}
				}
			}
			assert.True(t, found, "should have found calls metric")
		})
	}
}

func TestAdjustedCountAttribute_Histogram(t *testing.T) {
	// Test that histogram metrics also have the adjusted_count attribute when appropriate

	tests := []struct {
		name           string
		tracestate     string
		expectAdjusted bool
	}{
		{
			name:           "histogram with valid tracestate",
			tracestate:     "ot=th:8",
			expectAdjusted: true,
		},
		{
			name:           "histogram without tracestate",
			tracestate:     "",
			expectAdjusted: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p, err := newConnectorImp(nil, explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), true)
			require.NoError(t, err)

			ctx := metadata.NewIncomingContext(t.Context(), nil)
			err = p.Start(ctx, componenttest.NewNopHost())
			require.NoError(t, err)
			defer func() { require.NoError(t, p.Shutdown(ctx)) }()

			traces := buildSampleTraceWithTracestate(tt.tracestate)

			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)

			// Build metrics twice to get actual values
			_ = p.buildMetrics()
			receivedMetrics := p.buildMetrics()

			require.NotEmpty(t, receivedMetrics.ResourceMetrics().Len(), "should have resource metrics")

			// Find the histogram metric (duration)
			found := false
			for i := 0; i < receivedMetrics.ResourceMetrics().Len(); i++ {
				rm := receivedMetrics.ResourceMetrics().At(i)
				for j := 0; j < rm.ScopeMetrics().Len(); j++ {
					sm := rm.ScopeMetrics().At(j)
					for k := 0; k < sm.Metrics().Len(); k++ {
						m := sm.Metrics().At(k)
						if m.Name() == metricNameDuration {
							require.Equal(t, pmetric.MetricTypeHistogram, m.Type())
							dps := m.Histogram().DataPoints()
							for l := 0; l < dps.Len(); l++ {
								dp := dps.At(l)
								val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)

								assert.True(t, hasAttr, "sampling.method attribute should always be present")
								if tt.expectAdjusted {
									assert.Equal(t, "extrapolated", val.Str(), "sampling.method should be extrapolated for histogram with valid tracestate")
								} else {
									assert.Equal(t, "counted", val.Str(), "sampling.method should be counted for histogram without tracestate")
								}
								found = true
							}
						}
					}
				}
			}
			assert.True(t, found, "should have found duration histogram metric")
		})
	}
}

func TestAdjustedCountAttribute_Events(t *testing.T) {
	// Test that event metrics also have the adjusted_count attribute when appropriate

	tests := []struct {
		name           string
		tracestate     string
		expectAdjusted bool
	}{
		{
			name:           "events with valid tracestate",
			tracestate:     "ot=th:8",
			expectAdjusted: true,
		},
		{
			name:           "events without tracestate",
			tracestate:     "",
			expectAdjusted: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p, err := newConnectorImp(nil, disabledHistogramsConfig, disabledExemplarsConfig, enabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), true)
			require.NoError(t, err)

			ctx := metadata.NewIncomingContext(t.Context(), nil)
			err = p.Start(ctx, componenttest.NewNopHost())
			require.NoError(t, err)
			defer func() { require.NoError(t, p.Shutdown(ctx)) }()

			// buildSampleTraceWithTracestate creates spans with events via initSpan
			traces := buildSampleTraceWithTracestate(tt.tracestate)

			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)

			// Build metrics twice to get actual values
			_ = p.buildMetrics()
			receivedMetrics := p.buildMetrics()

			require.NotEmpty(t, receivedMetrics.ResourceMetrics().Len(), "should have resource metrics")

			// Find the events metric
			found := false
			for i := 0; i < receivedMetrics.ResourceMetrics().Len(); i++ {
				rm := receivedMetrics.ResourceMetrics().At(i)
				for j := 0; j < rm.ScopeMetrics().Len(); j++ {
					sm := rm.ScopeMetrics().At(j)
					for k := 0; k < sm.Metrics().Len(); k++ {
						m := sm.Metrics().At(k)
						if m.Name() == metricNameEvents {
							require.Equal(t, pmetric.MetricTypeSum, m.Type())
							dps := m.Sum().DataPoints()
							for l := 0; l < dps.Len(); l++ {
								dp := dps.At(l)
								val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)

								assert.True(t, hasAttr, "sampling.method attribute should always be present")
								if tt.expectAdjusted {
									assert.Equal(t, "extrapolated", val.Str(), "sampling.method should be extrapolated for events with valid tracestate")
								} else {
									assert.Equal(t, "counted", val.Str(), "sampling.method should be counted for events without tracestate")
								}
								found = true
							}
						}
					}
				}
			}
			assert.True(t, found, "should have found events metric")
		})
	}
}

func TestConsumeTracesWithTracestate_ExtrapolatedValues(t *testing.T) {
	// Test that metric values are correctly extrapolated based on tracestate sampling probability.
	// This is a functional test that verifies the actual numeric values of metrics.
	//
	// buildSampleTraceWithTracestate creates:
	// - service-a: 2 spans (1 server kind, 1 client kind) - each has 1 event
	// - service-b: 1 span (server kind with error status) - has 1 event
	//
	// For th:8 (50% sampling), adjusted count = 2, so each span contributes 2 to metrics.

	tests := []struct {
		name                  string
		tracestate            string
		expectedAdjustedCount int64 // expected count per span (1 for no extrapolation, 2 for 50%, 4 for 25%)
		expectExtrapolated    bool  // whether metrics should have is_extrapolated attribute
	}{
		{
			name:                  "th:8 (50% sampling) - adjusted count 2",
			tracestate:            "ot=th:8",
			expectedAdjustedCount: 2,
			expectExtrapolated:    true,
		},
		{
			name:                  "th:c (25% sampling) - adjusted count 4",
			tracestate:            "ot=th:c",
			expectedAdjustedCount: 4,
			expectExtrapolated:    true,
		},
		{
			name:                  "no tracestate - no extrapolation",
			tracestate:            "",
			expectedAdjustedCount: 1,
			expectExtrapolated:    false,
		},
		{
			name:                  "tracestate without th field - no extrapolation",
			tracestate:            "ot=rv:abcdabcdabcdff",
			expectedAdjustedCount: 1,
			expectExtrapolated:    false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Use explicit histograms and events enabled to test all metric types
			p, err := newConnectorImp(nil, explicitHistogramsConfig, disabledExemplarsConfig, enabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), true)
			require.NoError(t, err)

			ctx := metadata.NewIncomingContext(t.Context(), nil)
			err = p.Start(ctx, componenttest.NewNopHost())
			require.NoError(t, err)
			defer func() { require.NoError(t, p.Shutdown(ctx)) }()

			traces := buildSampleTraceWithTracestate(tt.tracestate)

			err = p.ConsumeTraces(ctx, traces)
			require.NoError(t, err)

			// First call buildMetrics() emits zero value, second call emits actual value
			_ = p.buildMetrics()
			receivedMetrics := p.buildMetrics()

			require.NotEmpty(t, receivedMetrics.ResourceMetrics().Len(), "should have resource metrics")

			// Track totals across all services for verification
			var totalCalls int64
			var totalHistogramCount uint64
			var totalEvents int64

			for i := 0; i < receivedMetrics.ResourceMetrics().Len(); i++ {
				rm := receivedMetrics.ResourceMetrics().At(i)
				for j := 0; j < rm.ScopeMetrics().Len(); j++ {
					sm := rm.ScopeMetrics().At(j)
					for k := 0; k < sm.Metrics().Len(); k++ {
						m := sm.Metrics().At(k)
						switch m.Name() {
						case metricNameCalls:
							require.Equal(t, pmetric.MetricTypeSum, m.Type())
							dps := m.Sum().DataPoints()
							for l := 0; l < dps.Len(); l++ {
								dp := dps.At(l)
								totalCalls += dp.IntValue()

								// Verify sampling.method attribute
								val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)
								assert.True(t, hasAttr, "calls metric should always have sampling.method attribute")
								if tt.expectExtrapolated {
									assert.Equal(t, "extrapolated", val.Str(), "sampling.method should be extrapolated")
								} else {
									assert.Equal(t, "counted", val.Str(), "sampling.method should be counted")
								}
							}

						case metricNameDuration:
							require.Equal(t, pmetric.MetricTypeHistogram, m.Type())
							dps := m.Histogram().DataPoints()
							for l := 0; l < dps.Len(); l++ {
								dp := dps.At(l)
								totalHistogramCount += dp.Count()

								// Verify sampling.method attribute
								val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)
								assert.True(t, hasAttr, "histogram metric should always have sampling.method attribute")
								if tt.expectExtrapolated {
									assert.Equal(t, "extrapolated", val.Str(), "sampling.method should be extrapolated")
								} else {
									assert.Equal(t, "counted", val.Str(), "sampling.method should be counted")
								}
							}

						case metricNameEvents:
							require.Equal(t, pmetric.MetricTypeSum, m.Type())
							dps := m.Sum().DataPoints()
							for l := 0; l < dps.Len(); l++ {
								dp := dps.At(l)
								totalEvents += dp.IntValue()

								// Verify sampling.method attribute
								val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)
								assert.True(t, hasAttr, "events metric should always have sampling.method attribute")
								if tt.expectExtrapolated {
									assert.Equal(t, "extrapolated", val.Str(), "sampling.method should be extrapolated")
								} else {
									assert.Equal(t, "counted", val.Str(), "sampling.method should be counted")
								}
							}
						}
					}
				}
			}

			// buildSampleTraceWithTracestate creates 3 spans total (2 in service-a, 1 in service-b)
			// Each span should contribute expectedAdjustedCount to the total
			expectedTotalSpans := int64(3)
			expectedTotalCalls := expectedTotalSpans * tt.expectedAdjustedCount
			expectedTotalHistogramCount := uint64(expectedTotalSpans) * uint64(tt.expectedAdjustedCount)

			// Each span has 1 event (added by initSpan), so events = spans * adjustedCount
			expectedTotalEvents := expectedTotalSpans * tt.expectedAdjustedCount

			assert.Equal(t, expectedTotalCalls, totalCalls,
				"total calls should be %d spans × %d adjusted count = %d",
				expectedTotalSpans, tt.expectedAdjustedCount, expectedTotalCalls)

			assert.Equal(t, expectedTotalHistogramCount, totalHistogramCount,
				"total histogram count should be %d spans × %d adjusted count = %d",
				expectedTotalSpans, tt.expectedAdjustedCount, expectedTotalHistogramCount)

			assert.Equal(t, expectedTotalEvents, totalEvents,
				"total events should be %d spans × %d adjusted count = %d (each span has 1 event)",
				expectedTotalSpans, tt.expectedAdjustedCount, expectedTotalEvents)
		})
	}
}

func TestConsumeTracesWithMixedTracestate_DistinctMetrics(t *testing.T) {
	// Test that spans with mixed tracestate (some with "ot=th:" key, some without) generate
	// two distinct metrics when enable_metrics_sampling_method is true.
	// Spans are identical in all other aspects: same service, name, kind, status.
	traces := buildSampleTraceWithMixedTracestate()

	p, err := newConnectorImp(nil, explicitHistogramsConfig, disabledExemplarsConfig, enabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), true)
	require.NoError(t, err)

	ctx := metadata.NewIncomingContext(t.Context(), nil)
	err = p.Start(ctx, componenttest.NewNopHost())
	require.NoError(t, err)
	defer func() { require.NoError(t, p.Shutdown(ctx)) }()

	err = p.ConsumeTraces(ctx, traces)
	require.NoError(t, err)

	_ = p.buildMetrics()
	receivedMetrics := p.buildMetrics()

	require.NotEmpty(t, receivedMetrics.ResourceMetrics().Len(), "should have resource metrics")

	// Count data points by sampling.method for calls, duration, and events metrics
	var extrapolatedCalls, countedCalls int
	var extrapolatedHistogram, countedHistogram int
	var extrapolatedEvents, countedEvents int

	for i := 0; i < receivedMetrics.ResourceMetrics().Len(); i++ {
		rm := receivedMetrics.ResourceMetrics().At(i)
		for j := 0; j < rm.ScopeMetrics().Len(); j++ {
			sm := rm.ScopeMetrics().At(j)
			for k := 0; k < sm.Metrics().Len(); k++ {
				m := sm.Metrics().At(k)
				switch m.Name() {
				case metricNameCalls:
					dps := m.Sum().DataPoints()
					for l := 0; l < dps.Len(); l++ {
						dp := dps.At(l)
						val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)
						require.True(t, hasAttr, "calls metric should have sampling.method attribute")
						switch val.Str() {
						case "extrapolated":
							extrapolatedCalls++
						case "counted":
							countedCalls++
						}
					}
				case metricNameDuration:
					dps := m.Histogram().DataPoints()
					for l := 0; l < dps.Len(); l++ {
						dp := dps.At(l)
						val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)
						require.True(t, hasAttr, "histogram metric should have sampling.method attribute")
						switch val.Str() {
						case "extrapolated":
							extrapolatedHistogram++
						case "counted":
							countedHistogram++
						}
					}
				case metricNameEvents:
					dps := m.Sum().DataPoints()
					for l := 0; l < dps.Len(); l++ {
						dp := dps.At(l)
						val, hasAttr := dp.Attributes().Get(metricAttrSamplingMethod)
						require.True(t, hasAttr, "events metric should have sampling.method attribute")
						switch val.Str() {
						case "extrapolated":
							extrapolatedEvents++
						case "counted":
							countedEvents++
						}
					}
				}
			}
		}
	}

	// Should have exactly one metric for each sampling method (two distinct metrics)
	assert.Equal(t, 1, extrapolatedCalls, "should have one calls metric with sampling.method=extrapolated")
	assert.Equal(t, 1, countedCalls, "should have one calls metric with sampling.method=counted")
	assert.Equal(t, 1, extrapolatedHistogram, "should have one duration metric with sampling.method=extrapolated")
	assert.Equal(t, 1, countedHistogram, "should have one duration metric with sampling.method=counted")
	assert.Equal(t, 1, extrapolatedEvents, "should have one events metric with sampling.method=extrapolated")
	assert.Equal(t, 1, countedEvents, "should have one events metric with sampling.method=counted")
}

func TestConsumeTracesWithMixedTracestate_SingleMetric(t *testing.T) {
	// Same setup as TestConsumeTracesWithMixedTracestate_DistinctMetrics, but with
	// enable_metrics_sampling_method set to false. All spans aggregate into a single metric.
	traces := buildSampleTraceWithMixedTracestate()

	p, err := newConnectorImp(nil, explicitHistogramsConfig, disabledExemplarsConfig, enabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
	require.NoError(t, err)

	ctx := metadata.NewIncomingContext(t.Context(), nil)
	err = p.Start(ctx, componenttest.NewNopHost())
	require.NoError(t, err)
	defer func() { require.NoError(t, p.Shutdown(ctx)) }()

	err = p.ConsumeTraces(ctx, traces)
	require.NoError(t, err)

	_ = p.buildMetrics()
	receivedMetrics := p.buildMetrics()

	require.NotEmpty(t, receivedMetrics.ResourceMetrics().Len(), "should have resource metrics")

	var callsDataPoints, histogramDataPoints, eventsDataPoints int
	samplingMethodFound := false

	for i := 0; i < receivedMetrics.ResourceMetrics().Len(); i++ {
		rm := receivedMetrics.ResourceMetrics().At(i)
		for j := 0; j < rm.ScopeMetrics().Len(); j++ {
			sm := rm.ScopeMetrics().At(j)
			for k := 0; k < sm.Metrics().Len(); k++ {
				m := sm.Metrics().At(k)
				switch m.Name() {
				case metricNameCalls:
					dps := m.Sum().DataPoints()
					callsDataPoints = dps.Len()
					for l := 0; l < dps.Len(); l++ {
						_, ok := dps.At(l).Attributes().Get(metricAttrSamplingMethod)
						samplingMethodFound = samplingMethodFound || ok
					}
				case metricNameDuration:
					dps := m.Histogram().DataPoints()
					histogramDataPoints = dps.Len()
					for l := 0; l < dps.Len(); l++ {
						_, ok := dps.At(l).Attributes().Get(metricAttrSamplingMethod)
						samplingMethodFound = samplingMethodFound || ok
					}
				case metricNameEvents:
					dps := m.Sum().DataPoints()
					eventsDataPoints = dps.Len()
					for l := 0; l < dps.Len(); l++ {
						_, ok := dps.At(l).Attributes().Get(metricAttrSamplingMethod)
						samplingMethodFound = samplingMethodFound || ok
					}
				}
			}
		}
	}

	assert.Equal(t, 1, callsDataPoints, "should have single calls metric (all spans aggregated)")
	assert.Equal(t, 1, histogramDataPoints, "should have single duration metric (all spans aggregated)")
	assert.Equal(t, 1, eventsDataPoints, "should have single events metric (all spans aggregated)")
	assert.False(t, samplingMethodFound, "should not have sampling.method attribute when enable_metrics_sampling_method is false")
}

// buildSampleTraceWithMixedTracestate builds a trace with three spans that are identical in all aspects
// (service, name, kind, status) except tracestate: one has "ot=th:8" (50% sampling), one has none, one has "invalid-state".
func buildSampleTraceWithMixedTracestate() ptrace.Traces {
	traces := ptrace.NewTraces()

	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
					tracestate: "ot=th:8",
				},
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20},
					tracestate: "",
				},
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28},
					tracestate: "invalid-state",
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)
	return traces
}

// buildSampleTraceWithTracestate builds a sample trace similar to buildSampleTrace,
// but with the specified tracestate set on all spans.
func buildSampleTraceWithTracestate(tracestate string) ptrace.Traces {
	traces := ptrace.NewTraces()

	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
					tracestate: tracestate,
				},
				{
					name:       "/ping",
					kind:       ptrace.SpanKindClient,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10},
					tracestate: tracestate,
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(
		serviceSpans{
			serviceName: "service-b",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
					traceID:    [16]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
					tracestate: tracestate,
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)
	initServiceSpans(serviceSpans{}, traces.ResourceSpans().AppendEmpty())
	return traces
}

// buildLargeSampleTraceWithTracestate builds a larger trace with many spans for more realistic benchmarks.
func buildLargeSampleTraceWithTracestate(numSpans int, tracestate string) ptrace.Traces {
	traces := ptrace.NewTraces()

	spans := make([]span, numSpans)
	kinds := []ptrace.SpanKind{ptrace.SpanKindServer, ptrace.SpanKindClient, ptrace.SpanKindInternal}
	statuses := []ptrace.StatusCode{ptrace.StatusCodeOk, ptrace.StatusCodeError, ptrace.StatusCodeUnset}

	for i := range numSpans {
		spans[i] = span{
			name:       fmt.Sprintf("/endpoint-%d", i%10),
			kind:       kinds[i%len(kinds)],
			statusCode: statuses[i%len(statuses)],
			traceID:    [16]byte{byte(i), 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
			spanID:     [8]byte{byte(i), 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
			tracestate: tracestate,
		}
	}

	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans:       spans,
		}, traces.ResourceSpans().AppendEmpty(),
	)

	return traces
}

// BenchmarkConnectorConsumeTraces_WithTracestate benchmarks ConsumeTraces with ot.th tracestate values.
func BenchmarkConnectorConsumeTraces_WithTracestate(b *testing.B) {
	benchmarks := []struct {
		name       string
		tracestate string
	}{
		{
			name:       "NoTracestate",
			tracestate: "",
		},
		{
			name:       "Tracestate_th_8_50pct_sampling",
			tracestate: "ot=th:8",
		},
		{
			name:       "Tracestate_th_c_25pct_sampling",
			tracestate: "ot=th:c",
		},
		{
			name:       "Tracestate_th_1_6pct_sampling",
			tracestate: "ot=th:1",
		},
		{
			name:       "Tracestate_no_th_field",
			tracestate: "ot=rv:abcdabcdabcdff",
		},
		{
			name:       "Tracestate_complex",
			tracestate: "ot=th:c;rv:abcdabcdabcdff,vendor1=value1",
		},
	}

	for _, bm := range benchmarks {
		b.Run(bm.name, func(b *testing.B) {
			conn, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
			require.NoError(b, err)

			traces := buildSampleTraceWithTracestate(bm.tracestate)
			ctx := metadata.NewIncomingContext(b.Context(), nil)

			b.ResetTimer()
			for b.Loop() {
				_ = conn.ConsumeTraces(ctx, traces)
			}
		})
	}
}

// BenchmarkConnectorConsumeTraces_WithTracestate_LargeTrace benchmarks ConsumeTraces with larger traces.
func BenchmarkConnectorConsumeTraces_WithTracestate_LargeTrace(b *testing.B) {
	spanCounts := []int{10, 100, 500}
	tracestates := []struct {
		name  string
		value string
	}{
		{"NoTracestate", ""},
		{"Tracestate_th_8", "ot=th:8"},
	}

	for _, sc := range spanCounts {
		for _, ts := range tracestates {
			b.Run(fmt.Sprintf("Spans_%d/%s", sc, ts.name), func(b *testing.B) {
				conn, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
				require.NoError(b, err)

				traces := buildLargeSampleTraceWithTracestate(sc, ts.value)
				ctx := metadata.NewIncomingContext(b.Context(), nil)

				b.ResetTimer()
				for b.Loop() {
					_ = conn.ConsumeTraces(ctx, traces)
				}
			})
		}
	}
}

// BenchmarkConnectorConsumeTraces_WithTracestate_Parallel benchmarks parallel ConsumeTraces calls.
func BenchmarkConnectorConsumeTraces_WithTracestate_Parallel(b *testing.B) {
	benchmarks := []struct {
		name       string
		tracestate string
	}{
		{
			name:       "NoTracestate",
			tracestate: "",
		},
		{
			name:       "Tracestate_th_8",
			tracestate: "ot=th:8",
		},
	}

	for _, bm := range benchmarks {
		b.Run(bm.name, func(b *testing.B) {
			conn, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
			require.NoError(b, err)

			ctx := metadata.NewIncomingContext(b.Context(), nil)

			b.ResetTimer()
			b.RunParallel(func(pb *testing.PB) {
				// Each goroutine gets its own trace to avoid contention
				traces := buildSampleTraceWithTracestate(bm.tracestate)
				for pb.Next() {
					_ = conn.ConsumeTraces(ctx, traces)
				}
			})
		})
	}
}

// BenchmarkConnectorConsumeTraces_WithTracestate_ExponentialHistogram benchmarks with exponential histograms.
func BenchmarkConnectorConsumeTraces_WithTracestate_ExponentialHistogram(b *testing.B) {
	benchmarks := []struct {
		name       string
		tracestate string
	}{
		{
			name:       "NoTracestate",
			tracestate: "",
		},
		{
			name:       "Tracestate_th_8",
			tracestate: "ot=th:8",
		},
	}

	for _, bm := range benchmarks {
		b.Run(bm.name, func(b *testing.B) {
			conn, err := newConnectorImp(stringp("defaultNullValue"), exponentialHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
			require.NoError(b, err)

			traces := buildSampleTraceWithTracestate(bm.tracestate)
			ctx := metadata.NewIncomingContext(b.Context(), nil)

			b.ResetTimer()
			for b.Loop() {
				_ = conn.ConsumeTraces(ctx, traces)
			}
		})
	}
}

// buildTraceWithDifferentTracestates builds a trace with 3 spans, each with a different tracestate.
// This creates a worst-case scenario for the adjusted count cache (all cache misses).
func buildTraceWithDifferentTracestates() ptrace.Traces {
	traces := ptrace.NewTraces()

	// Service A: 2 spans with different tracestates
	initServiceSpans(
		serviceSpans{
			serviceName: "service-a",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
					tracestate: "ot=th:8;rv:abcd01", // Different rv value
				},
				{
					name:       "/ping",
					kind:       ptrace.SpanKindClient,
					statusCode: ptrace.StatusCodeOk,
					traceID:    [16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10},
					spanID:     [8]byte{0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10},
					tracestate: "ot=th:8;rv:abcd02", // Different rv value
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)

	// Service B: 1 span with yet another different tracestate
	initServiceSpans(
		serviceSpans{
			serviceName: "service-b",
			spans: []span{
				{
					name:       "/ping",
					kind:       ptrace.SpanKindServer,
					statusCode: ptrace.StatusCodeError,
					traceID:    [16]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x10},
					spanID:     [8]byte{0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18},
					tracestate: "ot=th:8;rv:abcd03", // Different rv value
				},
			},
		}, traces.ResourceSpans().AppendEmpty(),
	)

	initServiceSpans(serviceSpans{}, traces.ResourceSpans().AppendEmpty())
	return traces
}

// BenchmarkConnectorConsumeTraces_AdjustedCountCache compares ConsumeTraces performance
// with adjusted count cache hits for traces with the same tracestate and misses for traces with different tracestates.
func BenchmarkConnectorConsumeTraces_AdjustedCountCache(b *testing.B) {
	b.Run("CacheHit", func(b *testing.B) {
		conn, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
		require.NoError(b, err)

		traces := buildSampleTraceWithTracestate("ot=th:8;rv:abcd01")
		ctx := metadata.NewIncomingContext(b.Context(), nil)

		b.ReportAllocs()
		b.ResetTimer()
		for b.Loop() {
			_ = conn.ConsumeTraces(ctx, traces)
		}
	})

	b.Run("CacheMiss", func(b *testing.B) {
		conn, err := newConnectorImp(stringp("defaultNullValue"), explicitHistogramsConfig, disabledExemplarsConfig, disabledEventsConfig, cumulative, 0, []string{}, 1000, clockwork.NewFakeClock(), false)
		require.NoError(b, err)

		traces := buildTraceWithDifferentTracestates()
		ctx := metadata.NewIncomingContext(b.Context(), nil)

		b.ReportAllocs()
		b.ResetTimer()
		for b.Loop() {
			_ = conn.ConsumeTraces(ctx, traces)
		}
	})
}
