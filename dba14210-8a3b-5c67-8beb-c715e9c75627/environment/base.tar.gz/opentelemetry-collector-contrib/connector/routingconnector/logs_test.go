// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package routingconnector // import "github.com/open-telemetry/opentelemetry-collector-contrib/connector/routingconnector"

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/connector"
	"go.opentelemetry.io/collector/connector/connectortest"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/consumer/consumertest"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pipeline"

	"github.com/open-telemetry/opentelemetry-collector-contrib/connector/routingconnector/internal/metadata"
	"github.com/open-telemetry/opentelemetry-collector-contrib/connector/routingconnector/internal/plogutiltest"
	"github.com/open-telemetry/opentelemetry-collector-contrib/pkg/ottl"
	"github.com/open-telemetry/opentelemetry-collector-contrib/pkg/ottl/contexts/ottllog"
)

func TestLogsRegisterConsumersForValidRoute(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logs0 := pipeline.NewIDWithName(pipeline.SignalLogs, "0")
	logs1 := pipeline.NewIDWithName(pipeline.SignalLogs, "1")

	// The unqualified `attributes["X-Tenant"]` syntax is the legacy form that
	// defaults to resource context for backward compatibility. The modern form
	// is `resource.attributes["X-Tenant"]` which explicitly specifies the context.
	cfg := &Config{
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Statement: `route() where attributes["X-Tenant"] == "acme"`,
				Pipelines: []pipeline.ID{logs0},
			},
			{
				Condition: `attributes["X-Tenant"] == "*"`,
				Pipelines: []pipeline.ID{logs0, logs1},
			},
			{
				Statement: `route() where attributes["X-Tenant"] == "abc"`,
				Pipelines: []pipeline.ID{logs0},
				Action:    Copy,
			},
			{
				Statement: `route() where attributes["X-Tenant"] == "abc"`,
				Pipelines: []pipeline.ID{logs0},
				Action:    Move,
			},
		},
	}

	require.NoError(t, cfg.Validate())

	var defaultSink, sink0, sink1 consumertest.LogsSink

	router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
		logsDefault: &defaultSink,
		logs0:       &sink0,
		logs1:       &sink1,
	})

	conn, err := NewFactory().CreateLogsToLogs(t.Context(),
		connectortest.NewNopSettings(metadata.Type), cfg, router.(consumer.Logs))

	require.NoError(t, err)
	require.NotNil(t, conn)
	assert.True(t, conn.Capabilities().MutatesData)

	rtConn := conn.(*logsConnector)
	require.NoError(t, err)
	require.Same(t, &defaultSink, rtConn.router.defaultConsumer)

	route, ok := rtConn.router.routes[key("resource", rtConn.router.routeSlice[0].statementText)]
	assert.True(t, ok)
	require.Same(t, &sink0, route.consumer)

	route, ok = rtConn.router.routes[key("resource", rtConn.router.routeSlice[1].statementText)]
	assert.True(t, ok)

	routeConsumer, err := router.Consumer(logs0, logs1)
	require.NoError(t, err)
	require.Equal(t, routeConsumer, route.consumer)

	require.NoError(t, conn.Start(t.Context(), componenttest.NewNopHost()))

	assert.NoError(t, conn.Shutdown(t.Context()))
}

func TestLogsRoutingWithInferredContexts(t *testing.T) {
	// This test demonstrates context inference with explicit context-qualified paths.
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logsProd := pipeline.NewIDWithName(pipeline.SignalLogs, "prod")
	logsErrors := pipeline.NewIDWithName(pipeline.SignalLogs, "errors")

	cfg := &Config{
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Condition: `resource.attributes["env"] == "prod"`,
				Pipelines: []pipeline.ID{logsProd},
			},
			{
				Condition: `log.severity_text == "ERROR"`,
				Pipelines: []pipeline.ID{logsErrors},
			},
		},
	}

	var defaultSink, prodSink, errorsSink consumertest.LogsSink

	router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
		logsDefault: &defaultSink,
		logsProd:    &prodSink,
		logsErrors:  &errorsSink,
	})

	factory := NewFactory()
	conn, err := factory.CreateLogsToLogs(
		t.Context(),
		connectortest.NewNopSettings(metadata.Type),
		cfg,
		router.(consumer.Logs),
	)
	require.NoError(t, err)

	// Helper function to create logs with specific attributes
	createLogs := func(env, severity string) plog.Logs {
		logs := plog.NewLogs()
		rl := logs.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("env", env)
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty().SetSeverityText(severity)
		return logs
	}

	// Helper function to reset all sinks
	resetSinks := func() {
		prodSink.Reset()
		errorsSink.Reset()
		defaultSink.Reset()
	}

	// Helper function to assert sink counts
	assertSinkCounts := func(t *testing.T, prodCount, errorsCount, defaultCount int) {
		assert.Equal(t, prodCount, prodSink.LogRecordCount(), "prod sink count")
		assert.Equal(t, errorsCount, errorsSink.LogRecordCount(), "errors sink count")
		assert.Equal(t, defaultCount, defaultSink.LogRecordCount(), "default sink count")
	}

	testCases := []struct {
		name            string
		env             string
		severity        string
		expectedProd    int
		expectedErrors  int
		expectedDefault int
	}{
		{
			name:            "resource context routing: env=prod routes to prod sink",
			env:             "prod",
			severity:        "INFO",
			expectedProd:    1,
			expectedErrors:  0,
			expectedDefault: 0,
		},
		{
			name:            "log context routing: ERROR severity routes to errors sink",
			env:             "dev",
			severity:        "ERROR",
			expectedProd:    0,
			expectedErrors:  1,
			expectedDefault: 0,
		},
		{
			name:            "default routing: non-matching logs go to default",
			env:             "dev",
			severity:        "INFO",
			expectedProd:    0,
			expectedErrors:  0,
			expectedDefault: 1,
		},
		{
			name:            "multiple route matches: both prod env and ERROR severity",
			env:             "prod",
			severity:        "ERROR",
			expectedProd:    1,
			expectedErrors:  0,
			expectedDefault: 0,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			resetSinks()
			logs := createLogs(tc.env, tc.severity)
			require.NoError(t, conn.ConsumeLogs(t.Context(), logs))
			assertSinkCounts(t, tc.expectedProd, tc.expectedErrors, tc.expectedDefault)
		})
	}
}

func TestLogsAreCorrectlySplitPerResourceAttributeWithOTTL(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logs0 := pipeline.NewIDWithName(pipeline.SignalLogs, "0")
	logs1 := pipeline.NewIDWithName(pipeline.SignalLogs, "1")

	cfg := &Config{
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Condition: `IsMatch(attributes["X-Tenant"], ".*acme") == true`,
				Pipelines: []pipeline.ID{logs0},
			},
			{
				Statement: `route() where IsMatch(attributes["X-Tenant"], "_acme") == true`,
				Pipelines: []pipeline.ID{logs1},
			},
			{
				Statement: `route() where attributes["X-Tenant"] == "ecorp"`,
				Pipelines: []pipeline.ID{logsDefault, logs0},
			},
		},
	}

	var defaultSink, sink0, sink1 consumertest.LogsSink

	router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
		logsDefault: &defaultSink,
		logs0:       &sink0,
		logs1:       &sink1,
	})

	resetSinks := func() {
		defaultSink.Reset()
		sink0.Reset()
		sink1.Reset()
	}

	factory := NewFactory()
	conn, err := factory.CreateLogsToLogs(
		t.Context(),
		connectortest.NewNopSettings(metadata.Type),
		cfg,
		router.(consumer.Logs),
	)

	require.NoError(t, err)
	require.NotNil(t, conn)
	require.NoError(t, conn.Start(t.Context(), componenttest.NewNopHost()))
	defer func() {
		assert.NoError(t, conn.Shutdown(t.Context()))
	}()

	t.Run("logs matched by no expressions", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()
		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "something-else")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Len(t, defaultSink.AllLogs(), 1)
		assert.Empty(t, sink0.AllLogs())
		assert.Empty(t, sink1.AllLogs())
	})

	t.Run("logs matched one expression", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()

		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "xacme")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Empty(t, defaultSink.AllLogs())
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Empty(t, sink1.AllLogs())
	})

	t.Run("logs matched by one expression, multiple pipelines", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()

		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "ecorp")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Len(t, defaultSink.AllLogs(), 1)
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Empty(t, sink1.AllLogs())

		assert.Equal(t, 1, defaultSink.AllLogs()[0].LogRecordCount())
		assert.Equal(t, 1, sink0.AllLogs()[0].LogRecordCount())
		assert.Equal(t, defaultSink.AllLogs(), sink0.AllLogs())
	})
}

func TestLogsAreCorrectlyMatchOnceWithOTTL(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logs0 := pipeline.NewIDWithName(pipeline.SignalLogs, "0")
	logs1 := pipeline.NewIDWithName(pipeline.SignalLogs, "1")

	cfg := &Config{
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Statement: `route() where IsMatch(attributes["X-Tenant"], ".*acme") == true`,
				Pipelines: []pipeline.ID{logs0},
			},
			{
				Statement: `route() where IsMatch(attributes["X-Tenant"], "_acme") == true`,
				Pipelines: []pipeline.ID{logs1},
			},
			{
				Condition: `attributes["X-Tenant"] == "ecorp"`,
				Pipelines: []pipeline.ID{logsDefault, logs0},
			},
		},
	}

	var defaultSink, sink0, sink1 consumertest.LogsSink

	router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
		logsDefault: &defaultSink,
		logs0:       &sink0,
		logs1:       &sink1,
	})

	resetSinks := func() {
		defaultSink.Reset()
		sink0.Reset()
		sink1.Reset()
	}

	factory := NewFactory()
	conn, err := factory.CreateLogsToLogs(
		t.Context(),
		connectortest.NewNopSettings(metadata.Type),
		cfg,
		router.(consumer.Logs),
	)

	require.NoError(t, err)
	require.NotNil(t, conn)
	require.NoError(t, conn.Start(t.Context(), componenttest.NewNopHost()))
	defer func() {
		assert.NoError(t, conn.Shutdown(t.Context()))
	}()

	t.Run("logs matched by no expressions", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()
		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "something-else")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Len(t, defaultSink.AllLogs(), 1)
		assert.Empty(t, sink0.AllLogs())
		assert.Empty(t, sink1.AllLogs())
	})

	t.Run("logs matched one expression", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()

		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "xacme")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Empty(t, defaultSink.AllLogs())
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Empty(t, sink1.AllLogs())
	})

	t.Run("logs matched by two expressions, but sinks to one", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()

		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "x_acme")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		rl = l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "_acme")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Empty(t, defaultSink.AllLogs())
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Empty(t, sink1.AllLogs())

		assert.Equal(t, 2, sink0.AllLogs()[0].LogRecordCount())
	})

	t.Run("one log matched by multiple expressions, other matched none", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()

		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "_acme")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		rl = l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "something-else")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Len(t, defaultSink.AllLogs(), 1)
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Empty(t, sink1.AllLogs())

		rlog := defaultSink.AllLogs()[0].ResourceLogs().At(0)
		attr, ok := rlog.Resource().Attributes().Get("X-Tenant")
		assert.True(t, ok, "routing attribute must exists")
		assert.Equal(t, "something-else", attr.AsString())
	})

	t.Run("logs matched by one expression, multiple pipelines", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()

		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "ecorp")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Len(t, defaultSink.AllLogs(), 1)
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Empty(t, sink1.AllLogs())

		assert.Equal(t, 1, defaultSink.AllLogs()[0].LogRecordCount())
		assert.Equal(t, 1, sink0.AllLogs()[0].LogRecordCount())
		assert.Equal(t, defaultSink.AllLogs(), sink0.AllLogs())
	})
}

func TestLogsResourceAttributeDroppedByOTTL(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logsOther := pipeline.NewIDWithName(pipeline.SignalLogs, "other")

	cfg := &Config{
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Statement: `delete_key(attributes, "X-Tenant") where attributes["X-Tenant"] == "acme"`,
				Pipelines: []pipeline.ID{logsOther},
			},
		},
	}

	var sink0, sink1 consumertest.LogsSink

	router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
		logsDefault: &sink0,
		logsOther:   &sink1,
	})

	factory := NewFactory()
	conn, err := factory.CreateLogsToLogs(
		t.Context(),
		connectortest.NewNopSettings(metadata.Type),
		cfg,
		router.(consumer.Logs),
	)

	require.NoError(t, err)
	require.NotNil(t, conn)
	require.NoError(t, conn.Start(t.Context(), componenttest.NewNopHost()))
	defer func() {
		assert.NoError(t, conn.Shutdown(t.Context()))
	}()

	l := plog.NewLogs()
	rm := l.ResourceLogs().AppendEmpty()
	rm.Resource().Attributes().PutStr("X-Tenant", "acme")
	rm.Resource().Attributes().PutStr("attr", "acme")

	assert.NoError(t, conn.ConsumeLogs(t.Context(), l))
	logs := sink1.AllLogs()
	require.Len(t, logs, 1, "log should be routed to non-default exporter")
	require.Equal(t, 1, logs[0].ResourceLogs().Len())
	attrs := logs[0].ResourceLogs().At(0).Resource().Attributes()
	_, ok := attrs.Get("X-Tenant")
	assert.False(t, ok, "routing attribute should have been dropped")
	v, ok := attrs.Get("attr")
	assert.True(t, ok, "non routing attributes shouldn't be dropped")
	assert.Equal(t, "acme", v.Str())
	assert.Empty(t, sink0.AllLogs(),
		"metrics should not be routed to default pipeline",
	)
}

func TestLogsConnectorCapabilities(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logsOther := pipeline.NewIDWithName(pipeline.SignalLogs, "other")

	cfg := &Config{
		Table: []RoutingTableItem{{
			Statement: `route() where attributes["X-Tenant"] == "acme"`,
			Pipelines: []pipeline.ID{logsOther},
		}},
	}

	router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
		logsDefault: consumertest.NewNop(),
		logsOther:   consumertest.NewNop(),
	})

	factory := NewFactory()
	conn, err := factory.CreateLogsToLogs(
		t.Context(),
		connectortest.NewNopSettings(metadata.Type),
		cfg,
		router.(consumer.Logs),
	)

	require.NoError(t, err)
	assert.True(t, conn.Capabilities().MutatesData)
}

func TestLogsConnectorDetailed(t *testing.T) {
	idSink0 := pipeline.NewIDWithName(pipeline.SignalLogs, "0")
	idSink1 := pipeline.NewIDWithName(pipeline.SignalLogs, "1")
	idSinkD := pipeline.NewIDWithName(pipeline.SignalLogs, "default")

	isAcme := `request["X-Tenant"] == "acme"`

	isResourceA := `attributes["resourceName"] == "resourceA"`
	isResourceB := `attributes["resourceName"] == "resourceB"`
	isResourceX := `attributes["resourceName"] == "resourceX"`
	isResourceY := `attributes["resourceName"] == "resourceY"`

	isLogE := `body == "logE"`
	isLogF := `body == "logF"`
	isLogX := `body == "logX"`
	isLogY := `body == "logY"`

	// IsMap and IsString are just candidate for Standard Converter Function to prevent any unknown regressions for this component
	isBodyString := `IsString(body) == true`
	require.Contains(t, standardFunctions[*ottllog.TransformContext](), "IsString")
	isBodyMap := `IsMap(body) == true`
	require.Contains(t, standardFunctions[*ottllog.TransformContext](), "IsMap")

	isScopeCFromLowerContext := `instrumentation_scope.name == "scopeC"`
	isScopeDFromLowerContext := `instrumentation_scope.name == "scopeD"`

	isResourceBFromLowerContext := `resource.attributes["resourceName"] == "resourceB"`

	testCases := []struct {
		ctx         context.Context
		input       plog.Logs
		expectSink0 plog.Logs
		expectSink1 plog.Logs
		expectSinkD plog.Logs
		cfg         *Config
		name        string
	}{
		{
			name: "request/no_request_values",
			cfg: testConfig(
				withRoute("request", isAcme, idSink0),
				withDefault(idSinkD),
			),
			ctx:         t.Context(),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		{
			name: "request/match_any_value",
			cfg: testConfig(
				withRoute("request", isAcme, idSink0),
				withDefault(idSinkD),
			),
			ctx: withGRPCMetadata(
				withHTTPMetadata(
					t.Context(),
					map[string][]string{"X-Tenant": {"acme"}},
				),
				map[string]string{"X-Tenant": "notacme"},
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "request/match_grpc_value",
			cfg: testConfig(
				withRoute("request", isAcme, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withGRPCMetadata(t.Context(), map[string]string{"X-Tenant": "acme"}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "request/match_no_grpc_value",
			cfg: testConfig(
				withRoute("request", isAcme, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withGRPCMetadata(t.Context(), map[string]string{"X-Tenant": "notacme"}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		{
			name: "request/match_http_value",
			cfg: testConfig(
				withRoute("request", isAcme, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"acme"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "request/match_http_value2",
			cfg: testConfig(
				withRoute("request", isAcme, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"notacme", "acme"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "request/match_no_http_value",
			cfg: testConfig(
				withRoute("request", isAcme, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"notacme"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		{
			name: "resource/all_match_first_only",
			cfg: testConfig(
				withRoute("resource", "true", idSink0),
				withRoute("resource", isResourceY, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "resource/all_match_last_only",
			cfg: testConfig(
				withRoute("resource", isResourceX, idSink0),
				withRoute("resource", "true", idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "resource/all_match_only_once",
			cfg: testConfig(
				withRoute("resource", "true", idSink0),
				withRoute("resource", isResourceA+" or "+isResourceB, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "resource/each_matches_one",
			cfg: testConfig(
				withRoute("resource", isResourceA, idSink0),
				withRoute("resource", isResourceB, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("A", "CD", "EF"),
			expectSink1: plogutiltest.NewLogs("B", "CD", "EF"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "resource/some_match_with_default",
			cfg: testConfig(
				withRoute("resource", isResourceX, idSink0),
				withRoute("resource", isResourceB, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plogutiltest.NewLogs("B", "CD", "EF"),
			expectSinkD: plogutiltest.NewLogs("A", "CD", "EF"),
		},
		{
			name: "resource/some_match_without_default",
			cfg: testConfig(
				withRoute("resource", isResourceX, idSink0),
				withRoute("resource", isResourceB, idSink1),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plogutiltest.NewLogs("B", "CD", "EF"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "resource/match_none_with_default",
			cfg: testConfig(
				withRoute("resource", isResourceX, idSink0),
				withRoute("resource", isResourceY, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		{
			name: "resource/match_none_without_default",
			cfg: testConfig(
				withRoute("resource", isResourceX, idSink0),
				withRoute("resource", isResourceY, idSink1),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/all_match_first_only",
			cfg: testConfig(
				withRoute("log", "true", idSink0),
				withRoute("log", isLogY, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/all_match_last_only",
			cfg: testConfig(
				withRoute("log", isLogX, idSink0),
				withRoute("log", "true", idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/all_match_only_once",
			cfg: testConfig(
				withRoute("log", "true", idSink0),
				withRoute("log", isLogE+" or "+isLogF, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/each_matches_one",
			cfg: testConfig(
				withRoute("log", isLogE, idSink0),
				withRoute("log", isLogF, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "E"),
			expectSink1: plogutiltest.NewLogs("AB", "CD", "F"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/some_match_with_default",
			cfg: testConfig(
				withRoute("log", isLogX, idSink0),
				withRoute("log", isLogF, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plogutiltest.NewLogs("AB", "CD", "F"),
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "E"),
		},
		{
			name: "log/some_match_without_default",
			cfg: testConfig(
				withRoute("log", isLogX, idSink0),
				withRoute("log", isLogF, idSink1),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plogutiltest.NewLogs("AB", "CD", "F"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/match_none_with_default",
			cfg: testConfig(
				withRoute("log", isLogX, idSink0),
				withRoute("log", isLogY, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		{
			name: "log/match_none_without_default",
			cfg: testConfig(
				withRoute("log", isLogX, idSink0),
				withRoute("log", isLogY, idSink1),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/with_resource_condition",
			cfg: testConfig(
				withRoute("log", isResourceBFromLowerContext, idSink0),
				withRoute("log", isLogY, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("B", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("A", "CD", "EF"),
		},
		{
			name: "log/with_scope_condition",
			cfg: testConfig(
				withRoute("log", isScopeCFromLowerContext, idSink0),
				withRoute("log", isLogY, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "C", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "D", "EF"),
		},
		{
			name: "log/with_resource_and_scope_conditions",
			cfg: testConfig(
				withRoute("log", isResourceBFromLowerContext+" and "+isScopeDFromLowerContext, idSink0),
				withRoute("log", isLogY, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("B", "D", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogsFromOpts(
				plogutiltest.Resource("A",
					plogutiltest.Scope("C", plogutiltest.LogRecord("E"), plogutiltest.LogRecord("F")),
					plogutiltest.Scope("D", plogutiltest.LogRecord("E"), plogutiltest.LogRecord("F")),
				),
				plogutiltest.Resource("B",
					plogutiltest.Scope("C", plogutiltest.LogRecord("E"), plogutiltest.LogRecord("F")),
				),
			),
		},
		{
			name: "mixed/match_resource_then_logs",
			cfg: testConfig(
				withRoute("resource", isResourceA, idSink0),
				withRoute("log", isLogE, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("A", "CD", "EF"),
			expectSink1: plogutiltest.NewLogs("B", "CD", "E"),
			expectSinkD: plogutiltest.NewLogs("B", "CD", "F"),
		},
		{
			name: "mixed/match_logs_then_resource",
			cfg: testConfig(
				withRoute("log", isLogE, idSink0),
				withRoute("resource", isResourceB, idSink1),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "E"),
			expectSink1: plogutiltest.NewLogs("B", "CD", "F"),
			expectSinkD: plogutiltest.NewLogs("A", "CD", "F"),
		},
		{
			name: "mixed/match_resource_then_grpc_request",
			cfg: testConfig(
				withRoute("resource", isResourceA, idSink0),
				withRoute("request", isAcme, idSink1),
				withDefault(idSinkD),
			),
			ctx:         withGRPCMetadata(t.Context(), map[string]string{"X-Tenant": "acme"}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("A", "CD", "EF"),
			expectSink1: plogutiltest.NewLogs("B", "CD", "EF"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "mixed/match_logs_then_grpc_request",
			cfg: testConfig(
				withRoute("log", isLogF, idSink0),
				withRoute("request", isAcme, idSink1),
				withDefault(idSinkD),
			),
			ctx:         withGRPCMetadata(t.Context(), map[string]string{"X-Tenant": "acme"}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "F"),
			expectSink1: plogutiltest.NewLogs("AB", "CD", "E"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "mixed/match_resource_then_http_request",
			cfg: testConfig(
				withRoute("resource", isResourceA, idSink0),
				withRoute("request", isAcme, idSink1),
				withDefault(idSinkD),
			),
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"acme"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("A", "CD", "EF"),
			expectSink1: plogutiltest.NewLogs("B", "CD", "EF"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "mixed/match_logs_then_http_request",
			cfg: testConfig(
				withRoute("log", isLogF, idSink0),
				withRoute("request", isAcme, idSink1),
				withDefault(idSinkD),
			),
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"acme"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "F"),
			expectSink1: plogutiltest.NewLogs("AB", "CD", "E"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/with_converter_function_is_string",
			cfg: testConfig(
				withRoute("log", isBodyString, idSink0),
				withDefault(idSinkD),
			),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSinkD: plog.Logs{},
		},
		{
			name: "log/with_converter_function_is_map",
			cfg: testConfig(
				withRoute("log", isBodyMap, idSink0),
				withDefault(idSinkD),
			),
			input: plogutiltest.NewLogsFromOpts(
				plogutiltest.Resource("A", plogutiltest.Scope("B", setLogRecordMap(plogutiltest.LogRecord("C"), "key", "value"))),
			),
			expectSink0: plogutiltest.NewLogsFromOpts(
				plogutiltest.Resource("A", plogutiltest.Scope("B", setLogRecordMap(plogutiltest.LogRecord("C"), "key", "value"))),
			),
			expectSinkD: plog.Logs{},
		},
		{
			name: "otelcol_client_metadata/http_match",
			cfg: testConfig(
				withRoute("otelcol", `otelcol.client.metadata["X-Tenant"][0] == "acme"`, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"acme"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "otelcol_client_metadata/http_no_match",
			cfg: testConfig(
				withRoute("otelcol", `otelcol.client.metadata["X-Tenant"][0] == "acme"`, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"other"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		{
			name: "otelcol_client_metadata/no_metadata",
			cfg: testConfig(
				withRoute("otelcol", `otelcol.client.metadata["X-Tenant"][0] == "acme"`, idSink0),
				withDefault(idSinkD),
			),
			ctx:         t.Context(),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		// otelcol.[0] only checks the first value — unlike legacy request context which
		// checks ALL values. This documents the behavioral difference for migrating users.
		{
			name: "otelcol_client_metadata/http_value_not_at_index0",
			cfg: testConfig(
				withRoute("otelcol", `otelcol.client.metadata["X-Tenant"][0] == "acme"`, idSink0),
				withDefault(idSinkD),
			),
			// "acme" is at index 1 — otelcol.[0] only checks first value, so no match
			ctx:         withHTTPMetadata(t.Context(), map[string][]string{"X-Tenant": {"other", "acme"}}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
		// otelcol.grpc.metadata routes (gRPC metadata; gRPC lowercases keys)
		{
			name: "otelcol_grpc_metadata/grpc_match",
			cfg: testConfig(
				withRoute("otelcol", `otelcol.grpc.metadata["x-tenant"][0] == "acme"`, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withGRPCMetadata(t.Context(), map[string]string{"x-tenant": "acme"}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink1: plog.Logs{},
			expectSinkD: plog.Logs{},
		},
		{
			name: "otelcol_grpc_metadata/grpc_no_match",
			cfg: testConfig(
				withRoute("otelcol", `otelcol.grpc.metadata["x-tenant"][0] == "acme"`, idSink0),
				withDefault(idSinkD),
			),
			ctx:         withGRPCMetadata(t.Context(), map[string]string{"x-tenant": "other"}),
			input:       plogutiltest.NewLogs("AB", "CD", "EF"),
			expectSink0: plog.Logs{},
			expectSink1: plog.Logs{},
			expectSinkD: plogutiltest.NewLogs("AB", "CD", "EF"),
		},
	}

	for _, tt := range testCases {
		t.Run(tt.name, func(t *testing.T) {
			var sinkD, sink0, sink1 consumertest.LogsSink
			router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
				pipeline.NewIDWithName(pipeline.SignalLogs, "0"):       &sink0,
				pipeline.NewIDWithName(pipeline.SignalLogs, "1"):       &sink1,
				pipeline.NewIDWithName(pipeline.SignalLogs, "default"): &sinkD,
			})

			conn, err := NewFactory().CreateLogsToLogs(
				t.Context(),
				connectortest.NewNopSettings(metadata.Type),
				tt.cfg,
				router.(consumer.Logs),
			)
			require.NoError(t, err)

			ctx := t.Context()
			if tt.ctx != nil {
				ctx = tt.ctx
			}

			require.NoError(t, conn.ConsumeLogs(ctx, tt.input))

			assertExpected := func(sink *consumertest.LogsSink, expected plog.Logs, name string) {
				if expected == (plog.Logs{}) {
					assert.Empty(t, sink.AllLogs(), name)
				} else {
					require.Len(t, sink.AllLogs(), 1, name)
					assert.Equal(t, expected, sink.AllLogs()[0], name)
				}
			}
			assertExpected(&sink0, tt.expectSink0, "sink0")
			assertExpected(&sink1, tt.expectSink1, "sink1")
			assertExpected(&sinkD, tt.expectSinkD, "sinkD")
		})
	}
}

func TestLogsForPropagateError(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logs0 := pipeline.NewIDWithName(pipeline.SignalLogs, "0")

	cfg := &Config{
		ErrorMode:        ottl.PropagateError,
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Statement: `route() where ToLowerCase(attributes["unknown"]) == "acme"`,
				Pipelines: []pipeline.ID{logs0},
			},
		},
	}
	require.NoError(t, cfg.Validate())

	var defaultSink, sink0 consumertest.LogsSink
	conn, err := NewFactory().CreateLogsToLogs(t.Context(),
		connectortest.NewNopSettings(metadata.Type), cfg, connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
			logsDefault: &defaultSink,
			logs0:       &sink0,
		}))
	require.NoError(t, err)

	require.NoError(t, conn.Start(t.Context(), componenttest.NewNopHost()))
	require.Error(t, conn.ConsumeLogs(t.Context(), plogutiltest.NewLogs("1", "2", "3")))
	require.NoError(t, conn.Shutdown(t.Context()))

	assert.Empty(t, sink0.AllLogs(), 0)
	assert.Empty(t, defaultSink.AllLogs(), 0)
}

func TestLogsForIgnoreError(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logs0 := pipeline.NewIDWithName(pipeline.SignalLogs, "0")

	cfg := &Config{
		ErrorMode:        ottl.IgnoreError,
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Statement: `route() where ToLowerCase(attributes["unknown"]) == "acme"`,
				Pipelines: []pipeline.ID{logs0},
			},
		},
	}
	require.NoError(t, cfg.Validate())

	var defaultSink, sink0 consumertest.LogsSink
	conn, err := NewFactory().CreateLogsToLogs(t.Context(),
		connectortest.NewNopSettings(metadata.Type), cfg, connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
			logsDefault: &defaultSink,
			logs0:       &sink0,
		}))
	require.NoError(t, err)

	require.NoError(t, conn.Start(t.Context(), componenttest.NewNopHost()))
	require.NoError(t, conn.ConsumeLogs(t.Context(), plogutiltest.NewLogs("1", "2", "3")))
	require.NoError(t, conn.Shutdown(t.Context()))

	assert.Empty(t, sink0.AllLogs())
	assert.Len(t, defaultSink.AllLogs(), 1)
	assert.Equal(t, plogutiltest.NewLogs("1", "2", "3"), defaultSink.AllLogs()[0])
}

func TestLogsCopyAndMoveConfig(t *testing.T) {
	logsDefault := pipeline.NewIDWithName(pipeline.SignalLogs, "default")
	logs0 := pipeline.NewIDWithName(pipeline.SignalLogs, "0")
	logs1 := pipeline.NewIDWithName(pipeline.SignalLogs, "1")

	cfg := &Config{
		DefaultPipelines: []pipeline.ID{logsDefault},
		Table: []RoutingTableItem{
			{
				Condition: `IsMatch(attributes["X-Tenant"], ".*acme") == true`,
				Pipelines: []pipeline.ID{logs0},
				Action:    Copy,
			},
			{
				Statement: `route() where IsMatch(attributes["X-Tenant"], "_acme") == true`,
				Pipelines: []pipeline.ID{logs1},
				Action:    Move,
			},
			{
				Statement: `route() where attributes["X-Tenant"] == "ecorp"`,
				Pipelines: []pipeline.ID{logsDefault, logs0},
			},
		},
	}

	var defaultSink, sink0, sink1 consumertest.LogsSink

	router := connector.NewLogsRouter(map[pipeline.ID]consumer.Logs{
		logsDefault: &defaultSink,
		logs0:       &sink0,
		logs1:       &sink1,
	})

	resetSinks := func() {
		defaultSink.Reset()
		sink0.Reset()
		sink1.Reset()
	}

	factory := NewFactory()
	conn, err := factory.CreateLogsToLogs(
		t.Context(),
		connectortest.NewNopSettings(metadata.Type),
		cfg,
		router.(consumer.Logs),
	)

	require.NoError(t, err)
	require.NotNil(t, conn)
	require.NoError(t, conn.Start(t.Context(), componenttest.NewNopHost()))
	defer func() {
		assert.NoError(t, conn.Shutdown(t.Context()))
	}()

	t.Run("logs are copied correctly", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()
		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "xacme")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Len(t, defaultSink.AllLogs(), 1)
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Empty(t, sink1.AllLogs())
	})

	t.Run("logs are moved correctly", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()
		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "abc")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Len(t, defaultSink.AllLogs(), 1)
		assert.Empty(t, sink0.AllLogs())
		assert.Empty(t, sink1.AllLogs())
	})

	t.Run("logs are copied and moved correctly", func(t *testing.T) {
		resetSinks()

		l := plog.NewLogs()
		rl := l.ResourceLogs().AppendEmpty()
		rl.Resource().Attributes().PutStr("X-Tenant", "_acme")
		rl.ScopeLogs().AppendEmpty().LogRecords().AppendEmpty()

		require.NoError(t, conn.ConsumeLogs(t.Context(), l))

		assert.Empty(t, defaultSink.AllLogs())
		assert.Len(t, sink0.AllLogs(), 1)
		assert.Len(t, sink1.AllLogs(), 1)
	})
}

func setLogRecordMap(lr plog.LogRecord, key, value string) plog.LogRecord {
	lr.Body().SetEmptyMap().PutStr(key, value)
	return lr
}
